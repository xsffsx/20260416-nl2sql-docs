# Design acceptance review — expected_response-required rerun

The input prerequisite is implemented and actually exercised. Three new Rhesis UI runs retain 90/90 planned records: 76 accepted native verdicts and fourteen explicit errors/failures. Full scoring success and universal semantic reference adherence are not claimed.

| Requirement | Evidence | Conclusion |
| --- | --- | --- |
| References come from current testcase expected_response | Actual requests reconstructed using the exact native expected_response; verified by build_rhesis_flex_report.py | All 87 attempted judge prompts matched |
| Missing Evidence-only reference cannot produce Pass/Fail | 1507/1528 scoring audits contain no execution, prompts or judge_response and have score null | Verified; both native executions are errors |
| Gold/combined keep valid references when source evidence is empty | 1507/1528 native testcase references and actual Gold-backed requests | Gold remains available; scores/errors reflect real runs |
| Same 30 questions, reference content and one bound metric per set | CSVs and bindings-readback.json | 90 unchanged testcase inputs verified |
| NL2SQL receives only the question; no SQL Pair | All ninety raw requests, canonical traces and provider audits in runs/*/api-proofs | 90/90 verified, including failed scoring |
| Data, Active Snapshot and model settings stay fixed | pre-run-verification.json and post-run-verification.json | Five fingerprints and runtime identities unchanged |
| UI launches; SDK hosts scoring only | Three launch screenshots, native configurations and launch-provenance.json | Three Fresh Outputs / Parallel / Test Set Metrics UI launches |
| Preserve all errors rather than assign invented scores | Native result exports and strict collector joins | Two missing references, three parsing errors, three HTTP 429, five native timeouts, one unsafe/non-SQL API output |
| Do not promote late replies to valid scores | Native timeout rows keep score null even when audit later contains a model verdict | Verified for all five native timeouts |
| Preserve old runs | history-verification.json compares ninety stored native outputs/metrics/verdicts | 90/90 unchanged |
| Show genuine metrics, complete prompt files and new case 1528 | Three real binding screenshots, templates, actual per-call prompt Markdown and full audits | Published with new report; browser review recorded separately |
| Every LLM verdict correctly follows the reference | Counterexamples 1473 Evidence-only and 1521 Gold-only | Not established; actual questionable Passes explicitly flagged |

## Case 1528

- Evidence-only: expected_response.evidence is empty. Evaluation error; no scoring SQL, no LLM call, no semantic score.
- Gold-only: accepted Pass. Actual output computes station-count ratio, with extra columns and rounding.
- Combined: accepted Fail. Its different actual SQL computes transaction-amount share, contradicting the Gold reference's station-count share.

## Limitations

The changed metric is FLEX-based with a user-required reference prerequisite and explicit prompt adaptations; it is not an unchanged paper reproduction. Three independent generations confound metric-only comparisons. GLM may still overrule or misread a supplied reference; model verdicts are not human business truth. Native platform rate limits, timeouts and malformed replies remain visible and were not hidden by retries or output replacement. Screenshots contain real UI state, not a simulated metric editor.
