# Design acceptance review

## Result

Three separate Test Sets were launched once each from Rhesis UI. All ninety planned cases have a native result, actual SQL, API identity, judge audit and source reference. There are 85 accepted LLM verdicts and five real parsing errors. Native Partial states remain unchanged. The reporting and traceability contract is satisfied; full successful scoring and expert-level business reliability are not claimed.

## Requirements and evidence

| Requirement | Evidence | Conclusion |
| --- | --- | --- |
| Three same-source cohorts, one expected response per testcase | Three CSVs, `references.json`, `import-readback.json`, `bindings-readback.json` | 30 × 3, matching original question/reference projections and one matching metric each |
| Original empty evidence retained | Source and imported 1507/1528 values are empty strings | Preserved; no missing-reference auto-pass rule |
| Use LLM-as-judge with FLEX criteria | Pinned original `upstream/`, `rhesis_flex_metrics.py`, `postgresql-prompt.diff` | Three official prompt variants reused; final score is the model's boolean |
| Real execution selects the branch | Complete actual/Gold execution rows in 90 metric audits | Every branch recomputed by pinned official comparison during report verification |
| Correct model-visible references | 90 archived prompts regenerated and compared exactly | Evidence has no Gold SQL/result or appended execution-match hint; Gold-only has no evidence Hint; combined has both |
| PostgreSQL adaptation is explicit | Exact source diff and manifest's real SQL semantics checks | SQLite wording adapted; unrelated school hints omitted; no answer rewrite or numeric tolerance |
| NL2SQL sees only the question | Native `raw_request.body` equals the original question-only object for all ninety calls | No evidence or Gold in generation requests |
| No SQL Pair Knowledge or reused conversation | Ninety canonical traces/provider audits in `runs/*/api-proofs/` | Bound Snapshot and actual generation/correction inputs verified empty; unique thread identities |
| Fixed data and configuration | Pre/post verification JSONs; five typed content fingerprints, 423,050 rows | Unchanged |
| UI launch and single assigned metric | Three launch captures and native run configuration/metric plans | Fresh Outputs, Parallel, Test Set metrics; one selected GLM model ID |
| Preserve errors and all denominators | Three native runs/exports, comparison JSON, raw judge replies | 90/90 recorded; 85 valid judgments, five evaluation errors, zero unexecuted slots |
| No fabricated error verdicts | Eleven boundary tests and collector checks | A native error's synthetic zero is not accepted as a valid FLEX false |
| No hidden retries or generation substitution | Single-call scoring implementation and 90 distinct API/metric identities | No rerun; no historical-output or alternate-model path |
| Historical official results preserved | `history-verification.json` | All thirty previous native outputs, metrics and verdicts unchanged |
| Current three-metric scope | User clarification recorded in OpenSpec design | Native SDK deactivated the absent prior metric; that activation state is disclosed and not a prerequisite |

## Required difficult cases

| Case | Observed behavior | Review conclusion |
| --- | --- | --- |
| 1507 / 1528, empty evidence | All three variants pass both cases; original evidence stays empty | These are model decisions from remaining context, not proof that evidence exists or a default pass mechanism |
| 1471, extra columns and precision | All three judge Pass; exact execution comparison differs | Demonstrates the intended semantic-versus-result distinction; does not establish global judge accuracy |
| 1531, evidence/Gold conflict | Evidence Pass; Gold/combined Fail | Average-price formula and top-spender source differ; references and generated queries both require review |
| 1482, source population conflict | Actual SQL filters EUR, requested in the question; Gold does not; combined fails while the other judges pass | The combined judge may over-trust Gold. It is not an expert verdict |
| 1526, amount/date conflict | Question says 634.8 on August 25; evidence includes August 24 example and 634.8; Gold filters 1513.12 on August 25 | Source content preserved. Gold/combined Pass despite empty or NULL-containing actual results is a business-review concern |
| 1479, missing required filter | All actual SQL omit CZK. Evidence Fail; Gold/combined Pass because year 2013 still matches | The judge can reproduce the accidental-answer problem FLEX aims to reduce |
| 1521, matching count with omitted CZE/boundary difference | All exact result checks match; evidence Fail, Gold/combined Pass | Matching this database result does not prove the requested predicate is present. The evidence reply provides no explanation |
| All thirty questions, output differences | No question has byte-identical SQL across all three runs | Not a controlled metric-only comparison; pairwise identical SQL remains possible |

## All five evaluation errors

| Variant | Question | Raw response problem | Native treatment |
| --- | --- | --- | --- |
| Evidence | 1526 | No single final JSON conclusion | Error preserved; no valid FLEX score |
| Gold | 1506 | Conclusion followed by prose | Error preserved; no valid FLEX score |
| Gold | 1509 | Conclusion followed by prose | Error preserved; no valid FLEX score |
| Combined | 1500 | No single final JSON conclusion | Error preserved; no valid FLEX score |
| Combined | 1506 | Additional content after JSON | Error preserved; no valid FLEX score |

A human may recognize a true/false statement inside a rejected reply. This run does not reinterpret that text: the frozen strict protocol requires a complete JSON response or final fenced conclusion. The report shows the unabridged raw reply, including on error. These failures do not authorize a silent retry or parser change.

## Limitations and release checks

- The no-Gold upstream variant retains system wording about reference queries. Some model reasons invent a typical reference. Actual prompt provenance proves it was not supplied.
- PostgreSQL, GLM-5.3, this thirty-question subset and question-only generation differ from the published FLEX expert-agreement study and BIRD leaderboard settings.
- No human business labels were obtained. A higher pass rate is not evidence of a more reliable judge. Document analysis is separate from the three scoring functions.
- Rhesis worker capacity was eight; UI Parallel does not by itself prove eight simultaneous NL2SQL requests. No manual concurrency setting was changed.
- Native scoring has a thirty-second connector RPC limit; no timeout was observed in these runs. The configured judge HTTP timeout remains recorded separately.
- Native error metrics contain score zero; the report uses their explicit error state and does not count them as valid rejections.
- The exact generated documentation includes all thirty expanded case sections, three references/outputs/replies each, source-paper links, CSV/JSON/ZIP downloads and direct native-result links. Browser/render review evidence is recorded separately in `browser-review.json` before final delivery.
- The original six static prompt drafts and prior reports remain historical design evidence. No executable entry point imports those drafts; all new scoring uses the pinned FLEX source and current three metrics.
