# Rhesis: three FLEX-based reference evaluations

Status: all three UI runs are archived: 90 outcomes, 85 accepted judgments and five response-format errors. The native runs remain Partial; no rerun or invented score replaces those errors. See `comparison.json`, `comparison.csv` and `design-review.md`. The [earlier registration investigation](implementation-blocker.md) is retained as history; prior metric activation is not a prerequisite for this experiment.

Three independent Rhesis Test Sets contain the same thirty BIRD debit-card questions. Each testcase has one `expected_response` JSON string:

| Variant | Reference fields | FLEX implementation |
| --- | --- | --- |
| Evidence | `evidence` | `FLEX_NoGroundTruth` |
| Gold SQL | `gold_sql` | `FLEX_NoHint` |
| Combined | `evidence`, `gold_sql` | `OpenAIJudge` |

Each set used Fresh Outputs through the existing NL2SQL REST Endpoint. Only the question reached NL2SQL; neither reference field entered its request. SQL Pair Knowledge remained empty. Each run has its own actual SQL, query/trace identities and output hashes. None of the thirty questions has byte-identical SQL across all three runs; some pairs can still match. Differences in aggregate scores cannot isolate the effect of the metric or reference content.

## Sources and preparation

- `upstream/source-lock.json`: FLEX commit `270abdba59306134adf0928b2ce92acb8fbd94eb`, file checksums, original code and Apache-2.0 license.
- `bird-mini-dev-pg.json`: complete official 500-question source at its pinned revision; `references.json` retains the thirty selected questions, original evidence, source SQL and reviewed POC identifier mapping.
- `gold-identifier-audit.json`: confirms the POC PostgreSQL Gold differs only by the declared identifier mapping.
- `manifest.json`: real schema, five verified table-content fingerprints, Active Snapshot/runtime identity, explicit generation/judge configuration and thirty successful Gold self-comparisons.
- Three `bird-flex-*-30.csv` files: thirty unique questions each, read back after generation. Questions 1507 and 1528 retain empty evidence.

Schema and data were read from the actual database using the existing read-only scorer role. No table, business Snapshot or model setting was changed during preparation. The exact frozen values are in the manifest, rather than embedded in evaluation code.

## Prompt adaptation

`postgresql-prompt.diff` contains the exact system-prompt edits. Correctness criteria come from the original FLEX source; the old custom Rhesis business-intent rubric and six static native-prompt drafts are not used.

| Change | Reason and verification |
| --- | --- |
| SQLite3 dialect paragraph → PostgreSQL typing/identifier paragraph | Real read-only checks in `manifest.json`: integer division, numeric division, NULL count, and rejection of a typed text/integer comparison. No numeric tolerance or reference rewrite is introduced. |
| Do not append fixed `DB_HINTS` about schools | Those columns are unrelated to the debit-card schema. The actual schema is supplied separately; evidence remains exactly the source text. |
| Official `correct` boolean → Rhesis binary score | Only the final valid LLM judgment determines score 1/0. Execution matching chooses the FLEX branch, not the final semantic verdict. |
| Strict JSON protocol parsing | Accept a complete JSON response or one final JSON fenced block, with exactly one boolean `correct` field. Do not infer a verdict from a substring, missing result, provider failure or timeout. |

Full and Gold-only variants receive both SQL queries. When execution differs, they also receive both results. Evidence-only uses Gold internally for branch selection but never sends Gold SQL, Gold results or the explicit execution-match hint to the judge. It retains the actual result only in the differing branch. Gold-only has no Hint block.

The original no-Gold experiment inherits system wording that mentions a reference query. This upstream limitation is retained and disclosed, not silently replaced with a new rubric. Empty evidence alone receives no predefined outcome. Question 1531's evidence/Gold calculation discrepancy also remains unchanged.

The BIRD-specific `execution_result2text_set` formatting functions are loaded from the pinned source. Judge-visible results follow its first/last ten rows and string-length policy; complete results remain the basis of execution comparison and are retained in the audit.

## Judge and errors

The explicitly selected judge is the existing Rhesis model recorded in the manifest, using the matching local credential profile. Its API key is never written into this bundle. GLM-5.3 requires enabled thinking; reasoning effort, token budget, temperature and timeout are explicit and identical across variants. See the [official model parameter documentation](https://docs.bigmodel.cn/cn/guide/models/text/glm-5.3).

`judge-preflight.json` is a model/protocol readiness check using Gold against itself, not a new NL2SQL test or benchmark score. The final three runs are not seeded with it.

Scoring calls make one judge request, without model replacement or extra retries. Generation/SQL failure, judge timeout, invalid conclusion or disconnected connector remains a real error with no invented FLEX score. Rhesis native status is preserved; all thirty planned cases remain in each run's totals.

## Verification and operation

Run the boundary tests:

```bash
script/evaluation/.venv/bin/python -m unittest discover -s script/evaluation -p test_rhesis_flex_metrics.py -v
```

They cover all three variants and both branches, reference corruption, empty evidence, model-visible field isolation, official result truncation, strict conclusion parsing, differing execution/LLM verdicts, no retry on provider failure and concurrent audit preservation.

The existing Rhesis Code Metrics connector hosts only scoring. Register the three named metrics from `script/evaluation/rhesis_flex_metrics.py`, keep its project/environment connection active, import each CSV through the UI, and assign its matching metric. Start each set through **Fresh Outputs → Parallel → Test Set Metrics**; the three sets run separately. Preserve actual launch screenshots, native run exports, per-call audits and knowledge/trace evidence.

The final report must separately label these as **FLEX-based PostgreSQL evaluations**, the older custom semantic judge and official BIRD execution scores. No score in this bundle is an official leaderboard submission.

## Recorded runs

| Reference | Native run | Pass | Valid Fail | Evaluation error |
| --- | --- | ---: | ---: | ---: |
| Evidence | `2b581e62-e753-4a83-9f06-2b12a0a650ba` | 18 | 11 | 1 |
| Gold SQL | `09f0086f-2928-41ef-82d0-d869a174618e` | 18 | 10 | 2 |
| Combined | `03aa59b6-0974-4edb-baf2-3392ba7946ae` | 16 | 12 | 2 |

All ninety prompts were reconstructed from the pinned source, full execution results and frozen references and matched the archived prompts exactly. Each result has independent query/thread/trace identities and verified empty actual SQL Pair input. Before/after table fingerprints and runtime identities match. Eleven boundary tests passed, including the distinction between a native error scored as zero by Rhesis and a valid judge false verdict.

The UI preflight was disabled after independent model readiness, schema, data, permissions, binding and runtime checks. No extra preflight NL2SQL call seeded these runs. Native CSVs were read from the same `/test_runs/{id}/download` endpoint used by the UI; the browser's blob-download event was not captured. All thirty records in each native CSV were verified.

## Run the scoring process for a new UI run

Use `runtime-versions.json` for the actual scoring dependencies. The included Python files are the executed project helpers; `upstream/` retains the unmodified FLEX source and license. Keep credentials outside this directory. The example paths below are operator-supplied private files.

```bash
RHESIS_ENVIRONMENT=local python rhesis_flex_metrics.py \
  --bundle . \
  --scorer-env /path/to/private-scorer.env \
  --opencode-config /path/to/private-model-profile.json \
  --token-file /path/to/private-rhesis-token.txt \
  --audit-dir /path/to/new-run-audits \
  --ex-evaluator evaluation_ex.py \
  --ex-sha256 da1bbcd4530be83692d7c650c814ea9704bb710d0c953eb75d02ccb38233cf89 \
  --rhesis-url http://localhost:8080 \
  --rhesis-project 8aa58678-d952-469f-af75-afefce0176a6
```

The private model profile must contain the provider and endpoint specified in the manifest. The scorer environment supplies `BIRD_SCORER_DSN` for the same read-only database. The audit directory must be new. This command registers scoring functions only; launch the Test Set through the UI. Company deployments must freeze their actual project, endpoint, schema/data and model configuration rather than reuse local runtime identifiers as proof.

## Reading the report

`case-analysis.json` contains document analysis, not scoring rules. The scoring process never reads it. It highlights reference conflicts and questionable judge decisions without changing scores. Examples include the missing CZK filter in 1479, the omitted CZE filter in 1521, contradictory references in 1482/1526/1531 and empty evidence in 1507/1528. No human business sign-off is claimed.

The published paper is included as `FLEX-NAACL-2025.pdf`, with authors, DOI, license and checksum in `paper-source.json`. Its expert-agreement results are not directly comparable to these thirty-case GLM pass rates.
