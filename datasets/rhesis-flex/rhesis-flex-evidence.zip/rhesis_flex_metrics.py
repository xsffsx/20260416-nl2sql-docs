"""Pinned FLEX prompts and LLM judgments exposed as three Rhesis Code Metrics."""

import argparse
import ast
import difflib
import hashlib
import json
import numbers
import re
import time
from pathlib import Path
from uuid import uuid4

import httpx
import psycopg
from dotenv import dotenv_values

from prepare_rhesis_flex import VARIANTS, reference
from rhesis_bird_metrics import official_ex
from run_bird_baseline import encode_value, score_case, sha256, write_json


METRIC_NAMES = {"evidence": "FLEX-based Evidence Only", "gold": "FLEX-based Gold SQL Only",
                "combined": "FLEX-based Evidence and Gold SQL"}


def literal_assignments(source):
    result = {}
    for node in ast.parse(source).body:
        if not isinstance(node, ast.Assign) or not isinstance(node.targets[0], ast.Name):
            continue
        value = node.value
        if isinstance(value, ast.Constant):
            result[node.targets[0].id] = ast.literal_eval(value)
        elif isinstance(value, ast.Call) and isinstance(value.func, ast.Attribute) and value.func.attr == "strip" and isinstance(value.func.value, ast.Constant):
            result[node.targets[0].id] = ast.literal_eval(value.func.value).strip()
    return result


class FlexSource:
    def __init__(self, directory):
        lock = json.loads((directory / "source-lock.json").read_text())
        for name, item in lock["files"].items():
            if sha256(directory / name) != item["sha256"]:
                raise ValueError("FLEX source checksum differs: " + name)
        base_text = (directory / "utils/judge/base.py").read_text()
        variant_text = (directory / "utils/judge/flex.py").read_text()
        self.namespace = literal_assignments(base_text) | literal_assignments(variant_text)
        # Load only official prompt-selection methods, never the upstream permissive parser.
        base = next(n for n in ast.parse(base_text).body if isinstance(n, ast.ClassDef) and n.name == "LLMJudge")
        base.body = [n for n in base.body if isinstance(n, ast.Assign) or
                     isinstance(n, ast.FunctionDef) and n.name in ("get_judge_prompt", "get_system_prompt")]
        exec(compile(ast.Module(body=[base], type_ignores=[]), "FLEX/base.py", "exec"), self.namespace)
        self.namespace["OpenAIJudge"] = self.namespace["LLMJudge"]
        variants = [n for n in ast.parse(variant_text).body if isinstance(n, ast.ClassDef) and
                    n.name in ("FLEX_NoGroundTruth", "FLEX_NoHint")]
        exec(compile(ast.Module(body=variants, type_ignores=[]), "FLEX/flex.py", "exec"), self.namespace)
        self.judges = {key: object.__new__(self.namespace[name]) for key, name in {
            "evidence": "FLEX_NoGroundTruth", "gold": "FLEX_NoHint", "combined": "OpenAIJudge"}.items()}
        helpers = [n for n in ast.parse((directory / "utils/prompts.py").read_text()).body
                   if isinstance(n, ast.FunctionDef) and n.name in ("format_value", "execution_result2text_set")]
        formatting = {"numbers": numbers}
        exec(compile(ast.Module(body=helpers, type_ignores=[]), "FLEX/prompts.py", "exec"), formatting)
        self.format_result = formatting["execution_result2text_set"]
        self.revision = lock["revision"]

    def prompts(self, variant, schema, question, actual_sql, gold_sql, evidence, actual_rows, gold_rows, strict):
        judge = self.judges[variant]
        original = judge.get_system_prompt(strict)
        system = original.replace("SQLite3 Compatibility", "PostgreSQL Compatibility")
        system = system.replace(
            "- Both queries are SQLite3 compatible, meaning integer division is not automatically converted to float division, and logical operators, column/table names are case-insensitive.",
            "- Both queries must be PostgreSQL compatible. Integer division truncates unless an operand is explicitly non-integer. Unquoted identifiers fold to lower case; quoted identifiers are case-sensitive.")
        system = system.replace(
            "- Both queries are SQLite3 compatible, meaning integer division is not automatically converted to float division, and logical operators are case-insensitive.",
            "- Both queries must be PostgreSQL compatible. Integer division truncates unless an operand is explicitly non-integer. Unquoted identifiers fold to lower case; quoted identifiers are case-sensitive.")
        system = system.replace("- comparison between string and integer is allowed in SQLite3.",
                                "- A typed text value cannot be compared directly with an integer without compatible explicit casts; follow the supplied schema types.")
        if "SQLite3" in system:
            raise ValueError("Unadapted SQLite3 criterion")
        actual_text = self.format_result(actual_rows, deduplicate=strict)[0]
        gold_text = self.format_result(gold_rows, deduplicate=strict)[0]
        user = judge.get_judge_prompt(strict).format(schema=schema, question=question,
                pred_query=actual_sql, pred_result=actual_text, gt_query=gold_sql, gt_result=gold_text)
        if judge.INCLUDE_EX_HINT:
            user += f"\n\nNote: two queries have {'same' if strict else 'different'} execution results.\n"
        if judge.USE_HINT:
            user += "\n**Hint**\n" + evidence
        visible = {"question": question, "schema": schema, "actual_sql": actual_sql}
        if variant != "evidence":
            visible["gold_sql"] = gold_sql
            visible["execution_match"] = strict
        if not strict:
            visible["actual_result"] = actual_text
            if variant != "evidence":
                visible["gold_result"] = gold_text
        if variant != "gold":
            visible["evidence"] = evidence
        return {"system": system, "user": user, "visible_fields": visible,
                "source_system_sha256": digest(original), "system_sha256": digest(system),
                "user_sha256": digest(user), "strict": strict}

    def adaptation_diff(self):
        patches = []
        for strict in (False, True):
            original = self.judges["combined"].get_system_prompt(strict)
            adapted = self.prompts("combined", "SCHEMA", "QUESTION", "ACTUAL", "GOLD", "EVIDENCE", [], [], strict)["system"]
            patches.extend(difflib.unified_diff(original.splitlines(True), adapted.splitlines(True),
                           fromfile="upstream-" + str(strict), tofile="postgresql-" + str(strict)))
        return "".join(patches)


def digest(value):
    return hashlib.sha256(value.encode()).hexdigest()


def parse_conclusion(content):
    if not isinstance(content, str):
        raise ValueError("Judge content is missing")
    conclusions = list(re.finditer(r"```json\s*\n(\{[^`]*\})\s*\n```", content))
    if conclusions:
        if len(conclusions) != 1 or content[conclusions[0].end():].strip():
            raise ValueError("Expected one final JSON conclusion")
        payload = conclusions[0].group(1)
    else:
        payload = content.strip()
    parsed = json.loads(payload)
    if set(parsed) != {"correct"} or type(parsed["correct"]) is not bool:
        raise ValueError("Judge conclusion must contain exactly one boolean correct field")
    return parsed["correct"]


class JudgeClient:
    def __init__(self, config, api_key):
        self.config = config
        self.client = httpx.Client(base_url=config["base_url"].rstrip("/") + "/",
                                  headers={"Authorization": "Bearer " + api_key}, timeout=config["timeout_seconds"])

    def __call__(self, prompts):
        request = {key: self.config[key] for key in ("model", "temperature", "max_tokens", "thinking", "reasoning_effort")}
        request["messages"] = [{"role": "system", "content": prompts["system"]}, {"role": "user", "content": prompts["user"]}]
        response = self.client.post("chat/completions", json=request)
        response.raise_for_status()
        return response.json()


class FlexMetric:
    def __init__(self, bundle, dsn, judge, audit_dir, calculate_ex):
        self.bundle = Path(bundle)
        self.manifest = json.loads((self.bundle / "manifest.json").read_text())
        self.manifest_sha256 = sha256(self.bundle / "manifest.json")
        if not self.manifest["schema"] or digest(self.manifest["schema"]) != self.manifest["schema_sha256"]:
            raise ValueError("Frozen schema checksum differs or schema is empty")
        if sha256(self.bundle / "references.json") != self.manifest["references_sha256"]:
            raise ValueError("Frozen reference file checksum differs")
        cases = json.loads((self.bundle / "references.json").read_text())
        self.references = {case["question"]: case for case in cases}
        if len(self.references) != 30:
            raise ValueError("Exactly thirty unique questions are required")
        self.source = FlexSource(self.bundle / "upstream")
        self.dsn, self.judge, self.audit_dir, self.calculate_ex = dsn, judge, Path(audit_dir), calculate_ex

    def evaluate(self, variant, input, output, expected_output):
        started = time.perf_counter()
        record = {"id": str(uuid4()), "variant": variant, "question": input,
                  "actual_sql": output, "actual_sql_sha256": digest(output) if isinstance(output, str) else None,
                  "judge": self.manifest["judge"], "score": None, "status": "error"}
        try:
            if sha256(self.bundle / "manifest.json") != self.manifest_sha256:
                raise ValueError("Frozen configuration drift")
            if input not in self.references or expected_output != reference(self.references[input], variant):
                raise ValueError("Question/reference differs from the frozen variant CSV")
            case = self.references[input]
            record.update(question_id=str(case["question_id"]), expected_response=expected_output,
                          gold_sql=case["gold_sql_postgresql_poc"], evidence=case["evidence"])
            with psycopg.connect(self.dsn, autocommit=True) as conn:
                conn.execute("SET default_transaction_read_only=on")
                conn.execute("SELECT set_config('max_parallel_workers_per_gather', %s, false)",
                             (str(self.manifest["parallel_workers_per_gather"]),))
                result = score_case(conn, output, case["gold_sql_postgresql_poc"], self.manifest["sql_timeout_ms"])
            record["execution"] = result
            if result["error"]:
                raise ValueError("Actual SQL execution failed: " + result["error"])
            strict = self.calculate_ex(result["predicted_rows"], result["gold_rows"]) == 1
            prompts = self.source.prompts(variant, self.manifest["schema"], input, output,
                        case["gold_sql_postgresql_poc"], case["evidence"], result["predicted_rows"], result["gold_rows"], strict)
            record["prompts"] = prompts
            response = self.judge(prompts)
            record["judge_response"] = response
            choice = response["choices"][0]
            if choice["finish_reason"] != "stop":
                raise ValueError("Judge response did not finish normally: " + str(choice["finish_reason"]))
            content = choice["message"]["content"]
            verdict = parse_conclusion(content)
            record.update(status="scored", score=int(verdict), correct=verdict, judge_reason=content)
            return {"score": int(verdict), "details": {"reason": content + "\nAudit: " + record["id"]}}
        except Exception as exc:
            record["error"] = {"type": type(exc).__name__, "message": str(exc)}
            raise
        finally:
            record["elapsed_ms"] = (time.perf_counter() - started) * 1000
            write_json(self.audit_dir / (record["id"] + ".json"), record)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for name in ("bundle", "scorer-env", "opencode-config", "token-file", "audit-dir", "ex-evaluator"):
        parser.add_argument("--" + name, type=Path, required=True)
    for name in ("rhesis-url", "rhesis-project", "ex-sha256"):
        parser.add_argument("--" + name, required=True)
    args = parser.parse_args()
    args.audit_dir.mkdir(parents=True, exist_ok=False)
    manifest = json.loads((args.bundle / "manifest.json").read_text())
    config = manifest["judge"]
    profile = json.loads(args.opencode_config.read_text())["provider"][config["provider"]]
    if profile["options"]["baseURL"].rstrip("/") != config["base_url"].rstrip("/"):
        raise ValueError("Judge credential endpoint differs from the frozen model")
    evaluator = FlexMetric(args.bundle, dotenv_values(args.scorer_env)["BIRD_SCORER_DSN"],
                           JudgeClient(config, profile["options"]["apiKey"]), args.audit_dir,
                           official_ex(args.ex_evaluator, args.ex_sha256))
    from rhesis.sdk import RhesisClient, metric

    client = RhesisClient(api_key=args.token_file.read_text().strip(), base_url=args.rhesis_url, project_id=args.rhesis_project)

    @metric(name=METRIC_NAMES["evidence"], score_type="binary",
            description=f"{config['name']} LLM-as-judge using pinned FLEX NoGroundTruth prompts adapted to PostgreSQL; evidence only to judge. Gold is internal branch context, never judge reference.")
    def evidence(input: str, output: str, expected_output: str) -> dict:
        return evaluator.evaluate("evidence", input, output, expected_output)

    @metric(name=METRIC_NAMES["gold"], score_type="binary",
            description=f"{config['name']} LLM-as-judge using pinned FLEX NoHint prompts adapted to PostgreSQL; Gold SQL reference, no evidence Hint. Final score is the LLM verdict.")
    def gold(input: str, output: str, expected_output: str) -> dict:
        return evaluator.evaluate("gold", input, output, expected_output)

    @metric(name=METRIC_NAMES["combined"], score_type="binary",
            description=f"{config['name']} LLM-as-judge using pinned full FLEX prompts adapted to PostgreSQL; evidence and Gold SQL reference. Final score is the LLM verdict, not execution equality.")
    def combined(input: str, output: str, expected_output: str) -> dict:
        return evaluator.evaluate("combined", input, output, expected_output)

    client.connect()


if __name__ == "__main__":
    main()
