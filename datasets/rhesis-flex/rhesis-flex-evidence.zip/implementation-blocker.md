# Implementation stopped before launch

**Resolved scope decision:** the user clarified that this experiment uses only the three FLEX metrics. Prior metric activation is not a prerequisite. Continue with the existing three registrations; retain this investigation as history, do not add the old metric or patch Rhesis. Native SDK activation changes remain recorded separately from immutable historical scores.

OpenSpec: `rhesis-flex-three-reference-evaluation`, 10/23 tasks complete. No benchmark run was launched. The scoring connector has been stopped; NL2SQL remains running.

## Completed preparation

- Three FLEX-derived LLM judges, fixed upstream source, PostgreSQL adaptation diff and frozen configuration.
- Ten boundary tests passed. One real judge readiness request returned a valid boolean; it is not a benchmark result.
- Three Test Sets imported through Rhesis UI, thirty records each. `import-readback.json` checks all ninety questions, expected responses and source metadata against their CSV files. Metric binding is not complete.

| Reference | Native Test Set |
| --- | --- |
| Evidence | [BIRD 30 — FLEX Evidence Only](http://localhost:3002/test-sets/94e3b640-15f0-4486-9fbb-dff37b8e6583) |
| Gold SQL | [BIRD 30 — FLEX Gold SQL Only](http://localhost:3002/test-sets/b72e09be-bfad-473d-800c-0b5622bf077f) |
| Both | [BIRD 30 — FLEX Evidence and Gold SQL](http://localhost:3002/test-sets/12572fd8-ee61-4131-8550-17b545cfe79c) |

## Conflict: registering a new connector disables the previous metric

Rhesis `apps/backend/src/rhesis/backend/app/services/connector/handlers/metric_sync.py` treats the connected SDK's registered metrics as the organization-wide list. `sync_sdk_metrics()` calls `_mark_inactive_metrics()`, which sets every existing SDK metric absent from that registration to Inactive. It does not limit this action to new FLEX metrics.

Readback confirms `BIRD Official Execution Accuracy` is now Inactive (`def4a463-3fef-436b-94e7-7cec8f4235f0`). This conflicts with design sections 3 and 7 and task 6.1, which require preserving the old metric. No historical run or score was rewritten. No native API status restoration or platform patch has been applied.

`registration-readback.json` preserves the current metrics, disconnected connector and the SDK detail API's HTTP 403 response. In the actual Metrics UI, SDK cards do not open an editor; `ui/registered-metrics.png` records the page. The frontend `MetricsDirectoryTab.tsx` only enables detail navigation for `custom` and `rhesis` backends; backend `routers/metric.py` similarly excludes `sdk` from detail reads.

## Corrected threshold investigation

The initial concern that a null database threshold would classify score zero as Pass was incorrect. The investigation initially missed `metric_model_to_config()` before the connector strategy. The running worker converts the null threshold to 0.5; a direct native boundary check returned zero → false and one → true. `native-threshold-check.json` records this check and hashes the worker's actual source files. No threshold change is needed.

## Proposed resolution requiring a design decision

Keep one connector responsible for both the existing BIRD metric and the three new FLEX metrics, reusing the original `BirdMetric` implementation for the old metric. Restore the old metric's intended enabled state through the native configuration API after verifying its prior configuration. This adds no new generation endpoint and changes no scoring rule, but expands the connector's declared ownership beyond the current three-metric design.

Alternatively, fix metric-registration ownership in Rhesis itself; that would explicitly expand the change into Rhesis source, currently excluded by the design.

Until that decision is made, do not start the thirty-case runs or publish a completed evaluation report. The ninety imports are retained. No valid FLEX benchmark scores exist yet; the ten tests and judge readiness request do not substitute for them.
