# POC 截图核对

已实际打开 [图像清单](bird-ui-images.json) 内全部 13 张图（11 张 POC、2 张 Opik），对照 API 与 Query DB 证据。

- review-*：5 个文件、各表行数、列名/类型与 source lock 一致；yearmonth.date 最终为 TEXT。transactions_1k 图只显示上部列，全部 9 列由实际 UI 输入值和目标 DB 类型核对验证，不声称截图覆盖全部列。
- 01 是切换类型时的中间态，最终以 review-yearmonth 和导入后的类型校验为准。
- 02：确认 5 表、423050 行后 Create schema。
- after-create-actual：5 表已进入 Draft，Guide 指向 Deploy；未激活。
- 04 / 05：正常 Publish 的 Draft 审阅与确认。
- 06：Snapshot 为 Active，bundleHash 与 Schema RAG ID 和 readiness API 一致，未发布变更数为 0。

截图保留在 bird-ui-evidence，受现有 PNG 忽略规则管理；没有覆盖 docs-site 已批准图片。准确率由完整执行评分给出，不由截图推断。

07：Opik dataset 为 v1，显示 30 条官方借记卡域题目；Gold/evidence 独立字段可读。09：完整 experiment 的 EX 平均 0.3，Ask 平均 19813.82 毫秒、错误/超时平均 0；case/query/trace 与指标列可见。UI 全部 30 case/query/trace ID 另由页面文本逐项核对，截图不代替完整读回。
