# 外部参考条件

检索日期：2026-10-24。以下为作者公开报告，未在本机重跑；仅作方法和条件参考。本轮 30 题 POC 上传数据与外部 500 题原生库在题集、数据类型、模型及预算上不同，**不能直接排名或宣称优劣**。条件一致后才能直接比较逐题结果。

| 系统 / 公开报告版本 | EX、题集与 Gold | 模型、evidence 与预算 | 数据 / 开发暴露条件 |
| --- | --- | --- | --- |
| [SDIP](https://github.com/zhouning/sdip-bird-minidev/blob/a678755a6356f394843c22c78420757c92c676bd/README.md)，2026-10-18 | 69.00%，500 题原生 PostgreSQL；HF `f65faf4a…`，官方 EX；旧 ZIP 同预测为 68.80% | gemini-3.8-flash，温度 0、thinking 关闭；evidence 开；每题 2–4 次 LLM、最多 3 轮、600 秒；训练题 few-shot retriever 关闭 | 官方 PG dump；ontology 含 schema/列说明，部分 FK 来自 dev Gold；Mini-Dev 与已调优 dev 重叠，ratio cast 等规则在分析 Mini-Dev 错题后加入。作者声明非 held-out。平台私有，不能据此证明与本项目 SQL Pair 机制等价。 |
| [FrontierSQL](https://github.com/Parth-Vasave/frontierSQL/blob/89a1ebd58f774d9fe44f6d09ba6a3bc81d471370/evaluation/results/BIRD_RUNS.md)，最终 run 2026-10-13，代码 `a226871` | 284/500，56.80%，原生 PostgreSQL；canonical HF Gold（该页未写完整 QA SHA）；旧 ZIP 为 56.60%；官方脚本复核一致 | Cerebras gpt-oss-120b、默认 reasoning；evidence 开；单候选、最多 2 次 repair；评分 statement 60 秒、官方脚本 meta timeout 30 秒 | 每域独立 schema；无 PG 并行。分析 242 条 test baseline 错题，修复在 dev 测量后最终 test 再跑；非完全未见 test。该页未披露 SQL Pair 开关及整体生成 wall budget。 |
| [Ontology2SQL](https://github.com/deeplethe/ontology2sql/blob/ece05d1cc988d9bce602a7a9e1b73cd5767a860a/RESULTS.md)，报告快照提交 2026-08-22 | 351/500，70.20% SQLite；329/500，65.80% PG 为 SQLite 预测经确定性方言适配回放，非 PG 重新生成；原生官方 PG dump；完整 Gold 修订未披露；EX 为精确行集合相等 | deepseek-v4-flash，温度 0、evidence 开、单候选、初始 12 步；600 秒内未完成的 52 题取首个无 wall cutoff 恢复尝试，20 题仍失败 | reviewed 语义映射 + 严格 Plan/IR compiler；声称 Gold 仅 scorer 使用；SQL Pair 检索配置/开发题暴露范围未充分披露。PG 两次复核 match vector 一致，但恢复预算与本轮不同。 |

本项目保留原始 PG Gold，仅经审阅的列名映射用于 POC 表；数据类型遵循真实 CSV Review。本次无 SQL Pair、单次 MCP 提交、系统原有最多 3 次纠错、Ask 180 秒、每条评分 SQL 30 秒。不是外部原生 PG 运行的复现。Gold 与自然语言可能存在歧义（如本轮 1526 Gold 得到 NULL）；本轮如实锁定官方答案，不按预测修正。

[BIRD 官方 Mini-Dev](https://github.com/bird-bench/mini_dev) 提供多方言数据与评分协议。外部报告的百分比只保存在本表，不伪造为 Opik 中的本地逐题结果。
