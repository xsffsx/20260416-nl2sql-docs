# BIRD POC 无 SQL Pair 基线结果

2026-10-24，完整运行 **9/30 EX（30%）**。30 题均终态、独立会话、一次 MCP 提交；执行错误 **0**、超时 **0**，其余 21 题为可执行 SQL 的完整结果不匹配。试跑独立保存，未合并、调参或用重跑替换基线。

[Opik 完整实验](http://localhost:17073/default/projects/01a16caf-2b08-740a-9dfb-6749c7da485f/experiments/01a16cdd-e2f7-755b-824a-c8f49904d4ed/compare?experiments=%5B%2201a16cf2-cfd0-7da4-bcf6-7c2e76472a8e%22%5D) · [dataset v1](http://localhost:17073/default/projects/01a16caf-2b08-740a-9dfb-6749c7da485f/datasets/01a16cdd-e2f7-755b-824a-c8f49904d4ed/items) · [本地 summary](runs/bird-debit-baseline-full-20261024-0800/summary.json) · [运行命令](bird-baseline-run.md)

## 范围与口径

- 项目 `bird_baseline_20261024`，真实 POC 上传 5 表、423,050 行、21 列，正常 Draft → Publish；导入前为空，完整值/类型在运行前后验证一致。[数据验证](bird-upload-content.json)
- QA 固定 HF `f65faf4ae3b638c1fa6df1d3370c8d92c8366301`，借记卡域全部 30 题，evidence 开；Gold 只允许列名映射并独立只读执行。[来源锁](../../script/evaluation/bird-debit-source-lock.json)
- 模型 API 名称 `mimo-v2.6-flash`，温度 0；Schema RAG 保留，SQL Pair 与 instructions 空；系统原有最多 3 次纠错，runner 无额外重试。模型供应方未披露权重修订。[实际配置](runs/bird-debit-baseline-full-20261024-0800/run-manifest.json)
- EX 按固定 BIRD 评分源码的 `set(predicted_rows) == set(gold_rows)`；只读事务完整取数、保留列序/NULL/原生数值，不使用 100 行 preview，不归一化、不加容差。Ask 限时 180 秒，每条评分 SQL 30 秒。[协议说明](bird-baseline-run.md)

平均 Ask **19.814 秒**，中位数 **16.603 秒**，范围 **8.235–55.697 秒**；累计 Ask 594.415 秒。平均 scorer **25.790 毫秒**。Opik 内置 duration 为记录已完成结果的任务耗时，真实模型链路耗时看 `ask_ms`；Pass rate 未配置断言，EX 看反馈分数 `EX` 的平均值。

| 难度 | 正确 / 题数 | EX |
| --- | ---: | ---: |
| simple | 4 / 14 | 28.57% |
| moderate | 5 / 12 | 41.67% |
| challenging | 0 / 4 | 0% |
| 全部 | 9 / 30 | 30% |

## 无知识与 Opik 验收

Active artifact `ea8a1aa0-46a1-4c99-aed0-18c5ac9c3a14`，bundle SHA-256 `50c0cc65c8c8fcd8aaac472f897ab6e1453ca8e8588380cec92bd8126ec7e0f7`。绑定的 [Snapshot](runs/bird-debit-baseline-full-20261024-0800/bound-snapshot.json) 中 SQL Pair 为空；30 次实际 provider 返回空文本/空选择，31 次 combined 生成阶段输入均为空；1506 首次非 JSON 响应触发系统既有阶段内重试，同次 MCP 后续成功。其他生成模式及 SQL 纠错阶段未执行，明确标记，不以“未执行”冒充已验证的空 prompt。终态错误 0 不表示没有中间尝试失败。

运行后收紧了 trace 完整性检查（连续事件序号、完成事件、实际模型阶段与 input 事件对应），对全部原始证据离线复核通过，没有新增模型调用。[严格复核](runs/bird-debit-baseline-full-20261024-0800/strict-proof-verification.json) 同时记录原 runner 与新 verifier 哈希；[实际执行源码](runs/bird-debit-baseline-full-20261024-0800/runner-source.py) 匹配原 manifest，不将后续检查器冒充当时的执行版本。

Opik dataset version ID `01a16cdd-e44a-7565-b9d7-faa5dbb98333`（v1），完整 experiment ID `01a16cf2-cfd0-7da4-bcf6-7c2e76472a8e`。API 读回核对项目/版本、全部 30 case、输出和 5 个分数；UI 核对 30 case/query/trace ID、v1、EX 0.3、错误/超时 0 及耗时列。[原始读回](runs/bird-debit-baseline-full-20261024-0800/opik-readback.json) · [UI 文本](runs/bird-debit-baseline-full-20261024-0800/opik-ui-readback.json) · [UI 逐项核对](runs/bird-debit-baseline-full-20261024-0800/opik-ui-verification.json)

Opik 原生 `trace_id` 与 NL2SQL `output.traceId` 是两套关联标识；前者记录结果发布任务，后者对应真实 Ask canonical trace，读回校验采用后者。[单题试跑](runs/bird-debit-smoke-20261024/opik-publication.json) 是独立实验，EX 0，不参与 30 题汇总。

## 逐题结果

下表诊断来自本轮预测 SQL 与完整结果的人工核对；不是修改 Gold 或放宽评分的理由。多返回辅助列的题还可能同时存在计算或筛选差异。

| 题号 / 原始证据 | EX | Ask 秒 | 不匹配说明 |
| --- | ---: | ---: | --- |
| [1471](runs/bird-debit-baseline-full-20261024-0800/1471/outcome.json) | 0 | 15.498 | 多出 EUR/CZK 计数列，ratio 另有 ROUND |
| [1472](runs/bird-debit-baseline-full-20261024-0800/1472/outcome.json) | 0 | 17.707 | 客户 ID 相同，多出消费汇总列 |
| [1473](runs/bird-debit-baseline-full-20261024-0800/1473/outcome.json) | 1 | 15.400 | 行集合一致 |
| [1476](runs/bird-debit-baseline-full-20261024-0800/1476/outcome.json) | 0 | 24.417 | 多出两列，浮点计算路径亦不同 |
| [1479](runs/bird-debit-baseline-full-20261024-0800/1479/outcome.json) | 0 | 13.961 | 多出汇总列，遗漏 CZK 筛选 |
| [1480](runs/bird-debit-baseline-full-20261024-0800/1480/outcome.json) | 0 | 30.655 | 年月与汇总两列；Gold 仅月份 |
| [1481](runs/bird-debit-baseline-full-20261024-0800/1481/outcome.json) | 0 | 55.697 | 最低消费/年度平均的聚合语义不同 |
| [1482](runs/bird-debit-baseline-full-20261024-0800/1482/outcome.json) | 0 | 47.518 | 百分比公式及输出行列不同 |
| [1483](runs/bird-debit-baseline-full-20261024-0800/1483/outcome.json) | 1 | 12.476 | 行集合一致 |
| [1484](runs/bird-debit-baseline-full-20261024-0800/1484/outcome.json) | 0 | 10.860 | 差值相同，多出两项计数 |
| [1486](runs/bird-debit-baseline-full-20261024-0800/1486/outcome.json) | 0 | 13.900 | 差值相同，多出计数及 Yes/No |
| [1490](runs/bird-debit-baseline-full-20261024-0800/1490/outcome.json) | 0 | 25.623 | 使用交易 amount 聚合，偏离 Gold yearmonth 条件 |
| [1493](runs/bird-debit-baseline-full-20261024-0800/1493/outcome.json) | 0 | 19.550 | ROUND 到 2 位、NUMERIC；Gold 原生浮点值 |
| [1498](runs/bird-debit-baseline-full-20261024-0800/1498/outcome.json) | 0 | 24.600 | 单客户最大记录替代按月汇总 |
| [1500](runs/bird-debit-baseline-full-20261024-0800/1500/outcome.json) | 0 | 20.355 | 加入交易日期匹配后空结果；Gold 非空 |
| [1501](runs/bird-debit-baseline-full-20261024-0800/1501/outcome.json) | 1 | 20.572 | 行集合一致 |
| [1505](runs/bird-debit-baseline-full-20261024-0800/1505/outcome.json) | 0 | 12.212 | COUNT(DISTINCT customer_id) 与 Gold COUNT 行不同 |
| [1506](runs/bird-debit-baseline-full-20261024-0800/1506/outcome.json) | 1 | 34.812 | 行集合一致 |
| [1507](runs/bird-debit-baseline-full-20261024-0800/1507/outcome.json) | 1 | 13.190 | 行集合一致 |
| [1509](runs/bird-debit-baseline-full-20261024-0800/1509/outcome.json) | 1 | 17.840 | 行集合一致 |
| [1514](runs/bird-debit-baseline-full-20261024-0800/1514/outcome.json) | 1 | 8.235 | 行集合一致 |
| [1515](runs/bird-debit-baseline-full-20261024-0800/1515/outcome.json) | 1 | 14.705 | 行集合一致 |
| [1521](runs/bird-debit-baseline-full-20261024-0800/1521/outcome.json) | 1 | 10.394 | 行集合一致 |
| [1524](runs/bird-debit-baseline-full-20261024-0800/1524/outcome.json) | 0 | 14.452 | 返回客户/segment/currency，Gold 为国家 |
| [1525](runs/bird-debit-baseline-full-20261024-0800/1525/outcome.json) | 0 | 18.142 | 日期过滤后的客户分母与 Gold 不同，另有 ROUND |
| [1526](runs/bird-debit-baseline-full-20261024-0800/1526/outcome.json) | 0 | 14.659 | 返回 3 列；官方 Gold 结果为单列 NULL |
| [1528](runs/bird-debit-baseline-full-20261024-0800/1528/outcome.json) | 0 | 10.028 | 返回所有 segment 统计；Gold 仅 Premium 百分比 |
| [1529](runs/bird-debit-baseline-full-20261024-0800/1529/outcome.json) | 0 | 23.623 | amount/consumption 替代 Gold price 聚合，列数亦不同 |
| [1531](runs/bird-debit-baseline-full-20261024-0800/1531/outcome.json) | 0 | 14.531 | 最贵客户选择和单价聚合不同，多出列 |
| [1533](runs/bird-debit-baseline-full-20261024-0800/1533/outcome.json) | 0 | 18.804 | 多出 customer_id；行集合比较保留列序 |

15 道错误题的非空预测结果列数与 Gold 不同，说明生成输出契约是后续值得独立研究的因素。1493 的提前 ROUND 改变数值；1505 的去重计数改变语义。1514 虽含重复行仍 EX=1，这是官方 row-set 指标忽略重复行的预期行为。

## 验证与限制

23 个评估契约测试通过（含真实只读 PostgreSQL），80 个受影响 backend 测试通过、2 个既有外部 DB 测试跳过。新增测试证明 canonical input 对应实际 prompt；本轮未修改 backend runtime proof，未触发全量 backend / mock E2E 99 条件。Mock 分数不参与结果。[评估契约日志](evaluator-contract-tests.txt) · [知识契约日志](knowledge-contract-tests.txt) · [backend 日志](affected-backend-tests.txt)

[外部参考条件表](bird-external-reference.md) 固定了公开报告版本、题集/Gold/方言、evidence、预算及开发题暴露。**本轮 30 题 POC 与外部 500 题原生库不能直接排名**；原生库类型、答案歧义和精确浮点比较均可能影响 EX，本轮未对这些条件做消融。

Langfuse localhost:3100 不可用，未将其作为证明来源；实际 canonical trace、provider API audit 与 Opik 均已保存。未统计未披露的 token/cost，不将未知成本记为零。[最终运行状态](bird-final-runtime.json) 证明正常服务重启后新项目仍 ready、配置一致，原项目 Active hash 和 5 张未登记表保持不变。

所有 JSON 原始证据与源码可用，未保存凭证或认证头；[校验清单](bird-evidence-sha256.json) 可复验报告、来源锁、测试和运行文件。原 HTML、draw.io、忽略规则与既有 docs-site 图片未替换；截图遵循现有忽略规则，本机副本及 hash 在 [UI 清单](bird-ui-images.json)。未提交 Git。
