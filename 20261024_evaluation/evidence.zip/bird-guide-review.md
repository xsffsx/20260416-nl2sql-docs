# BIRD Guide 交付与自审记录

状态：完成；2026-10-24T16:56:02+08:00，本地页面、正文、全部采用图片及附录已实际审阅。

## 操作与证据对应

| 阶段 | 真实行为 | 证据 |
| --- | --- | --- |
| 环境与来源 | 配置新空 POC 项目，核验固定 BIRD 来源 | bird-new-project-preflight / source lock |
| Import / Review | CSV data · POC 选择五表，确认名称和类型 | 现行 Guide、17 张通过产物及本轮导入记录 |
| Create schema | 导入数据形成 Draft，尚无 Active | 02-confirm-import、after-create-actual、bird-upload-draft |
| Deploy / Publish | 打开工作区、审阅并确认发布 | 05-publish-review、bird-published-readiness |
| Check readiness | 独立检查 QA 可用；不等于运行问题 | 原始 readiness 证据及现行通过 mock UI |
| 评估 | 独立会话真实 MCP、只读完整 SQL 评分 | 完整30题原始运行、Opik读回 |
| 查看结果 | dataset v1 与独立完整 experiment | 原始 Opik 截图、逐项读回 |

## 已完成来源与图像核对

- Monocart `11-poc-csv-reset/index.json`：2 passed、0 failed，17 张批准 POC Guide 图片全部 SHA-256 匹配报告 attachment；代码 captureCsvGuide 将同一 buffer 提交报告和文档，完整集合通过后才发布。
- 本篇采用其中 CSV 来源选择、readiness 通过两张，标记隔离 mock 操作示意；没有重新运行 E2E 或宣称它们是本轮 BIRD 成绩。
- 原始259个证据文件及35张既有 BIRD/POC批准图已保存/核对初始 hash。
- 已实际打开本篇全部9张采用图片：两张 mock，五张原始本轮记录，两张运行后只读复查图（Active、Opik 指标）；后者绑定原 Snapshot/hash，不包含原 Active 图片里的机器路径。
- 不采用 yearmonth Review 左侧高亮与内容不一致的图；导入后模型图可见 yearmonth.date 为 TEXT。所有旧 PNG 均未改写。

## 最终页面与验证

- URL：http://127.0.0.1:3001/20260416-nl2sql-docs/docs/examples/bird-baseline-no-sql-pair/
- 入口：Examples & Benchmarks → BIRD 无 SQL Pair 基线；旧 BIRD 页的历史演示说明也可进入新页，两条路径均已实际点击。
- 构建：`pnpm --dir docs-site build` 最终通过，Client/Server 均编译成功；本地采用现有 start 命令，127.0.0.1:3001，未部署公网。
- 浏览器：隔离 AI Chrome / CDP 9223 / Playwright MCP 8931，1366×900。8 个页面 figure 全部加载；9 个原图链接逐个实际打开并核对尺寸/加载成功；3 个折叠附录全部展开阅读并正常收起，页面 scrollWidth 1351 小于窗口1366，没有整体横向溢出。
- 静态资源：6 个 JSON + 9 张采用图片共15个 URL 均 HTTP200且服务端字节与源文件一致；14条公开文件 hash（校验文件自身除外）通过。
- 下载：真实点击“下载运行摘要”，Chrome 下载记录与实际下载文件字节均匹配公开 summary；下载事件未被 CDP 的 Playwright waitForEvent 捕获，因此没有把超时误认为页面下载失败。
- 可独立阅读：页面无 Opik 资源请求（浏览器资源记录为0），正文、图片与附件均由本站提供；没有停止或修改 Opik 服务来演示不可用。
- 最终直连：浏览器刷新及 Accept:text/html 的页面请求均为200；无 Accept 的 Python请求返回404，已从现有开发服务器路由源码确认其请求头处理规则，没有修改框架或添加兼容路径。
- 来源保护：259个原始基线证据文件、35张已有批准图片 hash 未变；17张原 Guide PNG 均匹配 Monocart 通过附件；公开件无实际本地秘密/认证头/机器路径，Git index 未触碰。

## 老板视角自审：发现、修正、复验

| 发现 | 修正 | 最终复验 |
| --- | --- | --- |
| 首屏 POC、SQL、EX、Ask 未在第一次出现时充分解释 | 改为概念验证、数据库查询语句、结果准确率、提问耗时；温度等参数移入附录 | 首屏不借助技术背景即可读到范围、9/30、错误0和19.8秒 |
| dataset / experiment / SDK / MCP 混在流程中，容易误以为产品有评估按钮 | 正文先用题集、实验记录、真实系统提问解释，再说明走现有接口和评估入口 | 区分表数据上传、题集登记、真实Ask、独立评分、Opik记录 |
| Opik全屏截图缩小后指标难读 | 只读打开同一实验，原生截取指标区域；原始完整图另保留链接 | 正文可读EX0.3、Ask19813.82ms、错误/超时0，原图可点击 |
| 旧 BIRD 页仍称导入即激活、无需Publish，并有旧SQLite归档路径 | 更新为Draft→Deploy→Publish→readiness，说明39表/226题为历史演示，修正已核实成员路径 | 从旧文进入新Guide，当前流程与产品Guide一致，批准截图未替换 |
| 原Active图带机器路径；yearmonth Review选择高亮存在歧义 | 不采用这些图作公开主图；只读复查原Active身份，模型图说明最终TEXT | 不修改旧PNG、不重新上传/Publish、不重跑模型 |
| 折叠附录自动化点击曾因Chrome窗口被遮挡而暂停动画 | 将既有隔离Chrome窗口置前，按正常动画等待完成后复验 | 3个附录均实际展开阅读；无force click、DOM文字替换或禁用动画 |

## 首次阅读者应能回答的问题

| 问题 | 页面给出的答案 |
| --- | --- |
| 为什么要做？ | 建立固定输入、配置、评分和追查记录的后续比较起点 |
| 从零到一做了什么？ | 独立空POC、官方来源五表、Review、Draft、正常Publish、readiness、试跑、完整30题、Opik读回 |
| 模型获得了什么？ | question/evidence与表结构检索；未获得Gold或SQL Pair，三层空知识证明有来源 |
| 30%如何得出？ | 完整只读结果比较，9正确/30；1509、1472、1493解释一致、多列和精度差异 |
| 错误0为什么仍有错题？ | 21题SQL可执行但结果不匹配；中间1506格式失败和既有重试未隐去 |
| 在哪里看、如何追查？ | Opik完整experiment及v1题集，字段解释、运行标识、静态30题/案例/来源/hash附件 |
| 能否与外部排行比较？ | 仅作条件参考，30题POC与500题原生库不能直接排名；模型、Gold、输入、预算和调优暴露尚未对齐 |

## 检查边界

本次只有文档、导航、精准图片忽略例外与精选静态副本改动；未重跑真实模型、外部系统、backend全量测试或mock E2E，复用的是已完整通过的既有E2E产物；未更改原始评分、Gold、Snapshot或批准图片，未引入fallback/workaround/兼容分支，没有证据支持的运行legacy清理未扩展执行。审阅为代理本人按老板视角的自审，不声称第三方独立评审。

## 本地审阅截图

以下文件按现有PNG忽略规则保留本机副本，正文所采用的公开图另在站点目录；每项已实际打开检查。

- [guide-top-final.png](bird-guide-review-images/guide-top-final.png) · SHA-256 `cfc69fd43e262f5d7537471aac3d69324ef609c2c8d5b1b5a649142514deffcb`
- [section-7-first.png](bird-guide-review-images/section-7-first.png) · SHA-256 `425382bf1060ba41b7da21a9162dbd55881645fb08a7c8d41560421729aa551a`
- [opik-reading-final.png](bird-guide-review-images/opik-reading-final.png) · SHA-256 `ec4dc49770e1c2a83777b7973835ad2ff6708c6b6cf9548c23ae7390cb2c55ae`
- [appendix-final.png](bird-guide-review-images/appendix-final.png) · SHA-256 `6b5837c9ce739b979e77d713eacf5bdab9431d12e0d12728cd7cf3ca24f0c2f4`
