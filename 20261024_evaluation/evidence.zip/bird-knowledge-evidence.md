# 无 SQL Pair 证明字段

沿用现有 canonical trace，未新增 runtime 字段、存储、禁用开关或问答分支。现有完整文本可提供长度计数的等效证明；缺失、None、脱敏、截断均不按空处理。

| 来源 | 实际字段 | 验证 |
| --- | --- | --- |
| 绑定 Snapshot | bundle.sqlPairs | 精确为空数组；比对实际 artifactVersionId、bundleHash、runtimeIdentity |
| 同次 provider API audit | response_json.sqlKnowledge / sqlKnowledgeChars / rag.selectedCount、selectedIds、selectedPairs | 文本精确空、长度 0、选择项精确空；query/thread/trace ID 与 Ask 一致 |
| reasoning / generating / combined 的 canonical qa.step.started | payload.input.artifacts.sql_samples_prompt | 字段存在、字符串、长度 0；实际 query 与白名单请求相同，histories=[] |
| 每次 correcting 的同类事件 | payload.input.artifacts.sqlKnowledge / attempt / maxRetries | 原始知识文本为空，保留每次尝试；output.artifacts.correction.llmInvoked=false 表示没有模型调用 |
| 阶段及运行关联 | phase、nodeId（阶段出现次数）、queryId、traceId | 来源 live/persisted，禁止 reconstructed；不存在的阶段为 not_executed |
| 版本 | 实际 MCP result 与前/后 /config/active | 每题比对绑定及进程模型 profile/参数；漂移 invalid |

Provider audit 通过既有 `/api/metadata/api-history?projectId=...&queryId=...` 列表及单条详情读取，只保存证明字段，不保存请求头。检索仍按正常 API、threshold、topK 执行；没有将 ragTopK 置零。

`asking_background._capture_step_input` 无条件保存完整阶段输入，`trace_sanitize` 不截断字符串。生产者从同一个 state 字段组装实际 prompt；纠错仅做去空白和段间换行，不会把非空知识变为空。新 `test_baseline_knowledge_evidence.py` 验证普通、combined 和每次纠错实际发出的 prompt 与捕获字段一致，覆盖 debug=false、provider 异常、无效纠错响应和 25,001 字符。因完整证据已存在，任务 2.2 无需再补一个重复计数。

53 个新/现有知识和 canonical trace 契约测试通过。Langfuse localhost:3100 不可达产生导出警告；本轮证明读取本地 canonical trace 和 API audit，不声称 Langfuse 可用。运行时实现保持原样。

16 个冻结模板已全文审阅，未发现借记卡题目或 Gold 答案；通用输出格式示例保留。模板 SHA-256 与审阅记录见 [bird-prompt-review.json](bird-prompt-review.json)，绑定 Snapshot 变化需重新审阅。
