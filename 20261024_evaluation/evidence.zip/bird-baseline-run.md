# 执行无 SQL Pair BIRD 基线

先按 [输入准备](bird-baseline-inputs.md) 重建固定输入，并通过真实 POC UI 发布；[无知识证明](bird-knowledge-evidence.md) 与 [模板审阅](bird-prompt-review.json) 必须匹配该 Snapshot。本次目标 `bird_baseline_20261024` 已完成此链路。

Opik 保存版本化题集、实验和逐题指标。本入口先执行真实 MCP 与独立 SQL 评分，再将同一次执行的结果提交 Opik，最后读回核对；不是在 Opik 中再次调用模型。Opik 自身 trace 的 duration 是结果入库任务耗时，原始 Ask 耗时看 `ask_ms`。

## 题集与本地连接

本次 30 题已通过 SDK 导入 [固定 dataset v1](bird-opik-dataset.json)。它包含 question/evidence、独立 Gold、难度与 case ID；MCP 请求只使用 question 和 evidence，整个 dataset item 不进入生成请求。

在新 Opik 环境初始化题集时，使用隔离环境中的相同 SDK；指定新的 dataset 名，不向现有版本追加题目：

```python
import json, sys, opik
sys.path.insert(0, 'script/evaluation')
from run_bird_baseline import dataset_items
manifest = json.load(open('script/evaluation/bird-debit-source-lock.json'))
client = opik.Opik(host='http://127.0.0.1:17073/api', workspace='default', project_name='nl2sql_followup')
dataset = client.create_dataset(name='YOUR_NEW_DATASET_NAME', project_name='nl2sql_followup')
assert not dataset.get_items()
dataset.insert(dataset_items(manifest))
version = dataset.get_version_info()
assert version is not None and version.items_total == 30
lock = {'host':'http://127.0.0.1:17073/api', 'workspace':'default', 'project_name':'nl2sql_followup',
        'dataset_name':dataset.name, 'dataset_id':dataset.id, 'version':version.model_dump(mode='json')}
with open('/path/to/new-dataset-lock.json', 'x') as output:
    json.dump(lock, output, indent=2)
```

只读评分连接放在忽略的本地 env，键为 `BIRD_SCORER_DSN`，采用 libpq 格式。评分角色只获目标 schema 的 USAGE 与 5 表 SELECT；设置 search_path 为该 schema。文件权限 600，不提交、不复制到报告。运行入口不记录 DSN、API key 或请求头。

## 执行

```bash
script/evaluation/.venv/bin/python script/evaluation/run_bird_baseline.py run \
  --pack /tmp/bird-inputs/new-pack \
  --source-lock script/evaluation/bird-debit-source-lock.json \
  --dataset-lock docs/20261024_evaluation/bird-opik-dataset.json \
  --prompt-review docs/20261024_evaluation/bird-prompt-review.json \
  --scorer-env script/evaluation/.baseline.local.env \
  --api-url http://127.0.0.1:4000 \
  --mcp-url http://127.0.0.1:4000/mcp/bird_baseline_20261024/ \
  --project bird_baseline_20261024 \
  --sql-timeout-ms 30000 --ask-timeout-seconds 180 \
  --output-dir /path/to/new-unique-run-directory
```

每次指定不存在的目录，它的名称用作新 experiment 名。`--smoke` 只运行首题，状态明确为 smoke；完整基线不加该参数，固定执行 30 题，不能将两轮拼接。准备入口使用 `prepare --help`，真实执行入口使用 `run --help`。

每题创建新 MCP session，从目标 endpoint 发现当前 Ask-capable 工具与 schema，不硬编码工具名。工具契约、项目、Snapshot 或模型 profile/参数漂移使整轮 invalid。每题只提交一次；系统原有校验和最多 3 次纠错保留，runner 不额外重试模型。

评分是同一 REPEATABLE READ、READ ONLY 事务中的 Gold 与预测完整结果比较。每条 statement 限时 30 秒，不使用项目 100 行 preview。采用锁定 BIRD EX 的 set(rows) 相等：忽略行序与重复行，保留列序、NULL 和原生数值比较，不加入容差、列重排或答案修复。

## 输出与失败契约

| 文件 | 内容 |
| --- | --- |
| run-manifest.json | 题号、来源/数据/模板哈希、实际 runtime binding 与模型参数、Git revision/dirty、runner 哈希、限时及 dataset version |
| gold-preflight.json | 全部 30 条 Gold 在评分前的独立只读执行结果 |
| 每题 request / mcp-response / trace-events | 白名单请求、同一次真实响应和持久化 canonical events |
| 每题 knowledge-audit / knowledge-proof | 实际 provider 响应与各阶段完整空知识输入证明 |
| 每题 score / outcome | 完整类型标记结果、EX、错误、真实 query/thread/trace ID 与 Ask/scorer 耗时 |
| opik-experiment-created / opik-readback / opik-publication | 远端身份、原始读回和通过一致性验证后的发布记录 |
| summary.json | complete / interrupted / invalid / publication_incomplete，planned/attempted/scored/remaining/unscored、错误与超时 |

普通模型/provider 失败、无 SQL、不安全 SQL、执行错误或评分超时，在测量前提有效时计 EX=0。Gold 错误、共享 DB 故障、知识污染、证明缺失或配置/数据漂移使整轮 invalid，未执行/未核实题不补零。进程中断保留已有证据。Opik 写入、score 或读回不一致为 publication_incomplete，非零退出；本地文件不会冒充发布成功。

只有完整且通过读回的运行才有最终 accuracy，分母固定 30。Ask 耗时为每题 MCP 发现/提交到响应返回的 wall time，scorer 耗时含解析、事务、Gold 和预测完整取数；二者分列。Opik 数值耗时按六位小数毫秒存储，EX 本身保持精确 0/1。

JSON 结果对 Decimal/date/time 使用带 type/value 的标记，保留证据可读性；比较先使用驱动原值完成。未知类型、非有限值或比较异常显式失败，不变换成近似匹配。

## 版本与验证

依赖版本由 [requirements.txt](../../script/evaluation/requirements.txt) 固定，Opik SDK 1.10.56、MCP 2.3.0；[实际解释器与包版本](bird-environment.json) 可核对；本次 [服务镜像身份](bird-opik-images.json) 记录实际 image ID，不依赖可变 latest 标签。模型的 API 名称、profile、温度、超时与 embedding 配置从实际进程读取；API 未披露权重修订，不能宣称固定了不可见的模型权重。

```bash
script/evaluation/.venv/bin/python -m unittest discover -s script/evaluation -v
cd src/backend_py
.venv/bin/python -m pytest -q tests/test_baseline_knowledge_evidence.py tests/test_sql_knowledge_provider.py tests/test_canonical_trace_coverage.py tests/test_trace_values.py tests/test_reason_and_generate_node.py tests/test_sql_validation_service.py tests/test_non_llm_step_output.py
```

数据库测试需将本地只读 DSN 传入 `BIRD_TEST_SCORER_DSN` 环境变量；本次 23 个评估测试（含 PostgreSQL）全通过，80 个受影响 backend 测试通过，2 个既有外部 DB 测试跳过。未修改 runtime proof 实现，因此未触发全量 backend / mock E2E 99 条件；mock 结果不参与本轮分数。

## 本次执行证据

[完整运行](runs/bird-debit-baseline-full-20261024-0800/summary.json) 与 [实际结果说明](bird-baseline-results.md) 保存真实 30 题；[单题试跑](runs/bird-debit-smoke-20261024/) 独立保留，不合并分数。

完整运行启动后，为拒绝整段阶段事件缺失，收紧了离线 proof 校验器；执行中的进程使用原已加载实现。`runner-source.py` 保留实际执行源码并匹配原 manifest 哈希；`strict-proof-verification.json` 记录新校验器哈希及全部 30 题原始证据复核。未重新调用模型、替换预测或变更 Snapshot。后续新运行自动归档执行源码。
