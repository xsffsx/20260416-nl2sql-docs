# Rhesis · BIRD official scoring · 2026-10-25

[Open the Test Run](http://localhost:3002/test-runs/f8ed743c-efdb-410c-a706-15610dbeb2e4?density=detail)

**Completed: 7/30 correct (23.3% execution accuracy); mean BIRD Soft F1 0.2802.** All 30 SQL queries executed; there were no metric or SQL execution errors. The other 23 queries returned results that differed from Gold.

## What ran

1. The existing Rhesis REST Endpoint sent only `{"query": "the question"}` to `POST /api/nl2sql?projectId=bird_baseline_20261024` and extracted `$.sql`.
2. The Test Set retained Gold SQL in `expected_response`; Gold and BIRD evidence were absent from all 30 API requests.
3. The Rhesis UI launched **Fresh Outputs → Parallel → Test Set Metrics**. The bound metric was **BIRD Official Execution Accuracy** (`bf03f75d-ecfe-4778-9ae9-7d9ceacd0f6e`). The connector registered one metric and no generation endpoints.
4. The metric executed actual and Gold SQL read-only, fetched complete results, and invoked the pinned official BIRD functions. Rhesis persisted all 30 binary scores. Every score and verdict was checked against the complete local result archive.

The UI's binary threshold is 0.5: official scores are exclusively 0 or 1, so only 1 passes. Soft F1 does not affect the verdict. This Rhesis build retains Code Metric `score` and `reason` but drops other returned details; each reason includes the official Soft F1 value, and the complete result tables are archived locally.

## Official rules

Source revision: `abd11b6db92a1c9f809b32f7564c7c71b34d67f0`.

| Function | Official source | SHA-256 |
| --- | --- | --- |
| `calculate_ex` | [evaluation_ex.py](https://github.com/bird-bench/mini_dev/blob/abd11b6db92a1c9f809b32f7564c7c71b34d67f0/evaluation/evaluation_ex.py) | `da1bbcd4530be83692d7c650c814ea9704bb710d0c953eb75d02ccb38233cf89` |
| `calculate_f1_score` and `calculate_row_match` | [evaluation_f1.py](https://github.com/bird-bench/mini_dev/blob/abd11b6db92a1c9f809b32f7564c7c71b34d67f0/evaluation/evaluation_f1.py) | `ba2700ee09b0c34d7e203788544757e6e6d6c99c0425bb92b3daa3927eee29bf` |

The connector checks these files and executes their original functions. The existing project scorer supplies SQL safety, read-only transactions, a 30,000 ms statement timeout and complete result retrieval. It does not replace the official scoring algorithms.

## Database control and validity

The scoring connection uses `max_parallel_workers_per_gather=0`. Before this was fixed, Gold 1476 and 1498 could differ from themselves at the last floating-point digits under parallel aggregation; Gold 1533 could return a different row order, affecting this revision's Soft F1. No SQL, result sorting, numeric rounding or tolerance was added. With the recorded setting, all 30 Gold self-comparisons produced execution accuracy 1 and Soft F1 1. This is a scoring-session setting; Rhesis still called NL2SQL in Parallel mode.

All five table fingerprints matched before and after execution: 423,050 rows. Every API result matched its query/thread/trace identifiers and bound Snapshot hash. All 30 provider audits and every executed generation/correction step proved empty SQL Pair input; each initial conversation history was empty.

This is a **30-case, question-only POC subset**, not a directly comparable official leaderboard submission. The old 5/30 run used different outputs and did not freeze this database execution setting; the new 7/30 is not evidence of an algorithm improvement. The historical 9/30 run also supplied BIRD evidence.

## Run again from the UI

Keep the scoring connector active. Its API token is private, project-scoped, and was created through the Rhesis API Tokens UI with a 30-day expiry. The token file contains only the raw token; it is not part of this evidence bundle.

From the repository root, start the connector with the existing local Rhesis SDK environment and a fresh audit directory:

```bash
RHESIS_ENVIRONMENT=local /Users/paulo/IdeaProjects/20260905_EVL/rhesis/sdk/.venv/bin/python \
  script/evaluation/rhesis_bird_metrics.py \
  --references docs/20261024_evaluation/rhesis/bird-question-only-30.csv \
  --scorer-env script/evaluation/.baseline.local.env \
  --ex-evaluator docs/20261024_evaluation/rhesis/evaluation_ex.py \
  --ex-sha256 da1bbcd4530be83692d7c650c814ea9704bb710d0c953eb75d02ccb38233cf89 \
  --f1-evaluator docs/20261024_evaluation/opik-review/evaluation_f1.py \
  --f1-sha256 ba2700ee09b0c34d7e203788544757e6e6d6c99c0425bb92b3daa3927eee29bf \
  --sql-timeout-ms 30000 --parallel-workers-per-gather 0 \
  --token-file /Users/paulo/.config/rhesis/bird-metrics-token.txt \
  --rhesis-url http://localhost:8080 \
  --rhesis-project 8aa58678-d952-469f-af75-afefce0176a6 \
  --output-dir docs/20261024_evaluation/rhesis/next-run-metric-results
```

Use the existing connector if it is already connected; do not launch a second connector for the same project/environment. Then open the Test Set, choose **Execute test set**, select **NL2SQL API — BIRD question only**, and retain **Test Set Metrics**, **Fresh Outputs** and **Parallel**. The metric definition is already bound to the Test Set.

The optional Rhesis model/endpoint preflight was disabled for this run. Instead, API readiness, complete data fingerprints, the connector's project/environment registration, metric binding and all 30 Gold self-checks were verified independently before launch. No evaluation LLM was used.

## Evidence

- [Summary](summary.json) and [30-case results](results.csv).
- [Native Rhesis result export](rhesis-export.csv), [full Test Results](rhesis-results.json) and [run configuration](rhesis-run.json).
- [Reviewed summary screenshot](ui-summary.png) and [UI launch settings](ui-launch.png).
- `metric-results/`: complete actual/Gold results, official scores and scoring errors for each case.
- `api-proofs/`: provider audits and persisted canonical results with the Snapshot and actual generation/correction input proof.
- `executed-connector.py`: exact scoring connector used in this run. The reusable connector later changed only audit filenames to support repeated UI runs without overwriting records, and reads a raw token file.

Official Rhesis integration: [Code Metrics](https://docs.rhesis.ai/docs/metrics/code-metrics), [Test Set Metrics and UI execution](https://docs.rhesis.ai/docs/test-runs/execution).
