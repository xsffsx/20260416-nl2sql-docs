# BIRD 无 SQL Pair 基线交付

2026-10-24：新空 POC 项目 `bird_baseline_20261024` 经真实 CSV 上传、Draft、Publish 完成；完整基线 **9/30 EX（30%）**，错误 0、超时 0。Opik 版本化 dataset、独立完整实验和读回证据均已保存。

- [实际结果、逐题分数与 Opik 链接](bird-baseline-results.md)
- [输入来源、重建命令与 Gold 审核](bird-baseline-inputs.md)
- [可执行命令与输出/失败契约](bird-baseline-run.md)
- [实际知识输入证明与源码测试映射](bird-knowledge-evidence.md)
- [外部成绩与评估条件](bird-external-reference.md)
- [UI 操作截图复核](bird-ui-review.md)

原项目 `debit_card_specializing` 检出 5 张未登记同名表后停止上传，检查记录保留在 [原始 preflight](baseline-bird-preflight.json)。用户随后明确选择新空 POC 项目；没有清空、覆盖或重置原项目。

原 HTML、draw.io、docs-site 已批准图片与忽略规则保留。未修改 backend runtime；复用现有完整 canonical input/provider audit，通过新增契约测试证明其忠实于实际 prompt。未引入 Cucumber、模型额外重试或答案归一化，也未删除未经证明可移除的 legacy。
