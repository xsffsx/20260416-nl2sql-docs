# Opik Test Suites guide — self-review

- **Page:** `http://127.0.0.1:3003/20260416-nl2sql-docs/docs/examples/opik-test-suites/`
- **Review date:** 2026-10-25 (Asia/Shanghai)
- **Live suite:** `bird-question-only-20261024-2134-opik-api`, version 3, 30 cases.
- **Build and browser:** `pnpm --dir docs-site build` passed. The local route returned HTTP 200; a 1280-pixel browser review confirmed all 39 referenced screenshots loaded.

## Coverage checked

The guide follows the actual local Opik UI through the Test suites list and a suite’s case table. It documents the visible controls and their popovers or drawers: suite creation from CSV/JSON or SDK, list search and filters, list columns and row selection, suite edit/delete, application settings, Expand with AI and its prompt, the Run menu and experiment setup, Test settings, adding and editing cases, case and suite tags, case actions, bulk case operations, density and columns, page sizes, and version history.

The Gold SQL example is a real case editor screenshot. Its Data contains only the question; the Gold SQL is in the case assertion. The API runner source confirms it builds the NL2SQL request from the question only (`question_only_request` returns the question as `query`). The setup screen reached from Run shows placeholder task code, so the guide does not present that screen as an automatic NL2SQL API run.

The guide links the relevant Opik documentation beside UI behavior: [Building Test Suites](https://www.comet.com/docs/opik/evaluation/advanced/building-test-suites), [Manage datasets](https://www.comet.com/docs/opik/evaluation/advanced/manage_datasets), and [Evaluation Concepts](https://www.comet.com/docs/opik/evaluation/concepts).

## Self-review findings and fixes

1. The earlier page covered only suite detail actions and left out the Test suites index, creation routes, suite metadata, and deletion confirmation. Added those flows first so a new reader can start at the left navigation.
2. Visual review found misaligned overlays on the AI form, Filters dialog, version metadata editor, list pagination, and case menus. Rebuilt the highlights against the screenshots captured from the live UI and checked the rendered overlays against the underlying text.
3. The Add assertion screenshot shows an empty editable field with example placeholder text. The page now says that clearly and keeps question data separate from Gold SQL criteria.
4. The UI copy icon in the suite SDK form and the experiment setup code were clicked; each displayed “Successfully copied code”. Share test case and Copy test case ID were also checked; they copy a URL and item ID and show confirmation toasts.
5. I opened the list, run, case-edit, filter, bulk-tag, table-column, density, page-size, and version controls in the local UI. I did not save their drafts or start an experiment.

## State and safety check

No suite, case, setting, tag, version, or Experiment was committed. While inspecting the case Actions menu, I clicked **Delete test case**; Opik staged the removal as a Draft. I immediately used **Discard changes**, then reloaded and verified version 3, all 30 cases, and the original case ID `01a16e1b-3f15-7286-80db-e01085b2688e` were present. I did not confirm suite deletion, export data, generate synthetic samples, run an Experiment, save settings, or restore a version.

Suite deletion was inspected only through its confirmation dialog. Opik’s warning says it removes all cases, moves linked Experiments to a “Deleted test suite” group, and cannot be undone. Item deletion is staged until the user chooses Save changes or Discard changes.

## Remaining limits

The local screens may differ from another Opik release or company deployment. Export, suite deletion, version restore, and an actual Experiment run were not executed; their results are described only from the visible controls and official documentation where linked.
