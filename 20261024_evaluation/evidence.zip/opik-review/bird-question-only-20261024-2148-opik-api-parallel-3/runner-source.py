"""Run the question-only BIRD cohort through the NL2SQL HTTP API and Opik."""

import argparse
import hashlib
import importlib.metadata
import json
import os
import time
from collections import Counter
from datetime import date, datetime, time as time_value
from decimal import Decimal
from pathlib import Path
from threading import Lock, local

from review_bird_opik import official_f1, readback, write
from run_bird_baseline import collect_knowledge_audit, score_case


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def verify_database_content(conn, source_lock, archived_tables):
    from psycopg import sql

    expected = {table['table']: table for table in archived_tables}
    if set(expected) != {table['csv_table'] for table in source_lock['tables']}:
        raise RuntimeError('Archived table fingerprints differ from the frozen source lock')
    verified = []
    for table in source_lock['tables']:
        name = table['csv_table']
        columns = [column['csv_name'] for column in table['columns']]
        actual_columns = [row[0] for row in conn.execute(
            'SELECT column_name FROM information_schema.columns '
            'WHERE table_schema = current_schema() AND table_name = %s ORDER BY ordinal_position', (name,)
        ).fetchall()]
        if actual_columns != columns:
            raise RuntimeError(f'Current BIRD table columns differ: {name}')
        statement = sql.SQL('SELECT {} FROM {}').format(
            sql.SQL(',').join(sql.Identifier(column) for column in columns), sql.Identifier(name)
        )
        rows = Counter(conn.execute(statement).fetchall())
        fingerprint = hashlib.sha256(repr(sorted(rows.items())).encode()).hexdigest()
        if rows.total() != table['row_count'] or rows.total() != expected[name]['rows']:
            raise RuntimeError(f'Current BIRD table row count differs: {name}')
        if fingerprint != expected[name]['typed_content_sha256']:
            raise RuntimeError(f'Current BIRD table content differs: {name}')
        verified.append({'table': name, 'rows': rows.total(), 'typed_content_sha256': fingerprint})
    return verified


def encode(value):
    if isinstance(value, (Decimal, date, datetime, time_value)):
        return {'type': type(value).__name__, 'value': str(value)}
    raise TypeError(f'Unsupported result type: {type(value).__name__}')


def write_encoded(path, data):
    Path(path).write_text(json.dumps(data, ensure_ascii=False, indent=2, default=encode) + '\n')


def question_only_request(item):
    return {'query': item['question']}


def validate_empty_knowledge(audits, query_id, thread_id, trace_id):
    for audit in audits:
        if (audit['query_id'] != query_id or audit['thread_key'] != thread_id or
                audit['trace_id'] != trace_id or audit['status_code'] != 200):
            raise RuntimeError('SQL Pair audit does not belong to the NL2SQL API call')
        response = audit['response_json']
        rag = response.get('rag', {})
        if (response.get('statusCode') != 200 or response.get('sqlKnowledge') != '' or
                response.get('sqlKnowledgeChars') != 0 or rag.get('selectedCount') != 0 or
                rag.get('selectedIds') != [] or rag.get('selectedPairs') != []):
            raise RuntimeError('NL2SQL API selected SQL Pair Knowledge')
    return {'provider_calls': len(audits), 'selected_pairs': 0,
            'status': 'verified_empty' if audits else 'no_provider_call'}


def compare_gold_assertions(report, suite_items, outcomes):
    suite_items_by_id = {item['id']: item for item in suite_items}
    cases = []
    for result_item in report['items']:
        suite_item = suite_items_by_id[result_item['dataset_item_id']]
        if len(result_item['runs']) != 1 or len(suite_item['assertions']) != 1:
            raise RuntimeError('Each question must have one run and one Gold SQL assertion')
        run = result_item['runs'][0]
        if run['input'] != {'question': suite_item['data']['question']}:
            raise RuntimeError('Opik task input differs from the question-only test data')
        if 'evidence' in run['input'] or 'gold_sql' in run['input'] or 'gold_sql' in run['output']:
            raise RuntimeError('Evidence or Gold SQL leaked into the NL2SQL task input/output')
        qid = run['output']['question_id']
        outcome = outcomes[qid]
        if suite_item['description'] != f"BIRD question {qid} | {outcome['case_id']}":
            raise RuntimeError('Test item description does not identify the evaluated question')
        assertion_text = suite_item['assertions'][0]
        assertion_result = next((entry for entry in run['assertions']
                                 if entry['name'] == assertion_text), None)
        if assertion_result is None or assertion_result['scoring_failed']:
            raise RuntimeError('Gold SQL assertion is missing or failed to score')
        cases.append({'question_id': qid, 'case_id': outcome['case_id'],
                      'judge_passed': assertion_result['passed'],
                      'official_EX_passed': outcome['EX'] == 1,
                      'agreed': assertion_result['passed'] == (outcome['EX'] == 1)})
    if len(cases) != len(outcomes) or {case['question_id'] for case in cases} != set(outcomes):
        raise RuntimeError('Gold SQL assertion did not cover all API calls')
    return {
        'items_total': len(cases),
        'judge_passed': sum(case['judge_passed'] for case in cases),
        'official_EX_passed': sum(case['official_EX_passed'] for case in cases),
        'agreement_count': sum(case['agreed'] for case in cases),
        'agreement_rate': sum(case['agreed'] for case in cases) / len(cases),
        'false_positive_question_ids': [case['question_id'] for case in cases
                                        if case['judge_passed'] and not case['official_EX_passed']],
        'false_negative_question_ids': [case['question_id'] for case in cases
                                        if not case['judge_passed'] and case['official_EX_passed']],
        'cases': cases,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--records', type=Path, required=True)
    parser.add_argument('--source-lock', type=Path, required=True)
    parser.add_argument('--baseline-run', type=Path, required=True)
    parser.add_argument('--dataset-lock', type=Path, required=True)
    parser.add_argument('--policy', type=Path, required=True)
    parser.add_argument('--evaluator', type=Path, required=True)
    parser.add_argument('--api-url', required=True)
    parser.add_argument('--project', required=True)
    parser.add_argument('--scorer-env', type=Path, required=True)
    parser.add_argument('--model-env', type=Path, required=True)
    parser.add_argument('--api-timeout-seconds', type=float, required=True)
    parser.add_argument('--sql-timeout-ms', type=int, required=True)
    parser.add_argument('--worker-threads', type=int, required=True)
    parser.add_argument('--output-dir', type=Path, required=True)
    parser.add_argument('--suite-name')
    args = parser.parse_args()
    if args.output_dir.exists():
        raise FileExistsError(args.output_dir)
    if args.api_timeout_seconds <= 0 or args.sql_timeout_ms <= 0 or args.worker_threads < 2:
        raise ValueError('Timeouts must be positive and worker_threads must be at least 2')

    import httpx
    import opik
    import psycopg
    from dotenv import dotenv_values
    from opik.evaluation import evaluate
    from opik.evaluation.metrics import BaseMetric
    from opik.evaluation.metrics.score_result import ScoreResult

    args.output_dir.mkdir(parents=True)
    bundle = json.loads(args.records.read_text())
    source_lock = json.loads(args.source_lock.read_text())
    baseline_manifest = json.loads((args.baseline_run / 'run-manifest.json').read_text())
    lock = json.loads(args.dataset_lock.read_text())
    policy = json.loads(args.policy.read_text())
    records = bundle['records']
    if len(records) != 30 or policy.get('input_protocol') != 'question_only':
        raise ValueError('The pinned question-only protocol must contain exactly 30 records')
    by_question = {record['question']: record for record in records}
    if len(by_question) != len(records):
        raise ValueError('Questions are not unique; Opik task mapping is ambiguous')
    if len({record['question_id'] for record in records}) != len(records):
        raise ValueError('Question IDs are not unique')
    if (sha256(args.source_lock) != baseline_manifest.get('source_lock_sha256') or
            set(source_lock['question_ids']) != {record['question_id'] for record in records}):
        raise ValueError('Source lock differs from the completed BIRD run')
    source_cases = {str(case['question_id']): case for case in source_lock['cases']}
    if any(record['question'] != source_cases[record['question_id']]['question'] or
           record['gold_sql'] != source_cases[record['question_id']]['gold_sql_postgresql_poc']
           for record in records):
        raise ValueError('Question or Gold SQL differs from the frozen BIRD source')

    env = dotenv_values(args.model_env)
    profile = 'LLM_PROFILE_' + env['LLM_CHAT_PROFILE'] + '_'
    if env[profile + 'PROVIDER'] != 'openai-compatible':
        raise ValueError('The configured Opik judge requires the openai-compatible provider')
    judge_model = 'openai/' + env[profile + 'MODEL']
    os.environ.update(OPENAI_API_KEY=env[profile + 'API_KEY'],
                      OPENAI_API_BASE=env[profile + 'BASE_URL'],
                      OPENAI_BASE_URL=env[profile + 'BASE_URL'],
                      OPIK_URL_OVERRIDE=lock['host'], OPIK_WORKSPACE=lock['workspace'],
                      OPIK_PROJECT_NAME=lock['project_name'])

    from run_bird_baseline import read_json_api

    scorer_env = dotenv_values(args.scorer_env)
    dsn = scorer_env['BIRD_SCORER_DSN']
    calculate_f1 = official_f1(args.evaluator, policy['evaluator_sha256'])
    client = opik.Opik(host=lock['host'], workspace=lock['workspace'], project_name=lock['project_name'])
    with httpx.Client(base_url=args.api_url, trust_env=False, timeout=args.api_timeout_seconds) as api, \
            psycopg.connect(dsn, autocommit=True) as conn:
        health = api.post('/api/health', params={'mode': 'project', 'projectId': args.project})
        health.raise_for_status()
        health_data = health.json()['project']
        if health_data.get('status') != 'ready' or not health_data.get('qaAvailable'):
            raise RuntimeError('NL2SQL project is not ready')
        checks = health_data.get('runtime', {}).get('checks', [])
        database_check = next((check for check in checks if check.get('key') == 'business-database'), None)
        query_pool_max = (database_check or {}).get('diagnostics', {}).get('pgQueryPoolMaxSize')
        if not isinstance(query_pool_max, int) or args.worker_threads >= query_pool_max:
            raise RuntimeError('worker_threads must leave capacity in the NL2SQL query pool')
        active = read_json_api(api, '/api/config/active', args.project)
        if (active.get('projectId') != args.project or active.get('status') != 'active' or
                active.get('summary', {}).get('sqlPairs', {}).get('count') != 0):
            raise RuntimeError('Active Snapshot is not the verified no-SQL-Pair configuration')
        frozen_runtime = {key: active.get(key) for key in ('artifactVersionId', 'bundleHash', 'runtimeIdentity')}

        db_identity = conn.execute('SELECT current_database(), current_user, current_schema()').fetchone()
        if not db_identity[0] or not db_identity[1] or not db_identity[2]:
            raise RuntimeError('Read-only scorer database identity is incomplete')
        verified_tables = verify_database_content(conn, source_lock, baseline_manifest['data'])
        gold_preflight = []
        for record in records:
            gold = score_case(conn, None, record['gold_sql'], args.sql_timeout_ms)
            actual_gold_rows = json.loads(json.dumps(gold['gold_rows'], default=encode))
            if gold['error'] != 'missing_sql':
                raise RuntimeError(f"BIRD Gold SQL preflight failed: {record['question_id']}")
            gold_preflight.append({'question_id': record['question_id'], 'status': 'verified',
                                   'rows': actual_gold_rows})
        write(args.output_dir / 'gold-preflight.json', gold_preflight)
        write(args.output_dir / 'database-identity.json', {
            'database': db_identity[0], 'role': db_identity[1], 'schema': db_identity[2],
            'source_table_content_verified': len(verified_tables), 'tables': verified_tables,
        })
        suite_name = args.suite_name or args.output_dir.name
        suite = client.get_or_create_evaluation_suite(
            name=suite_name,
            project_name=lock['project_name'],
            description='Question-only BIRD evaluation. Each item Data contains only the question; its item assertion contains the BIRD Gold SQL. The task calls POST /api/nl2sql; no SQL Pair Knowledge or BIRD evidence is sent.',
            assertions=policy['assertions'],
            execution_policy={'runs_per_item': 1, 'pass_threshold': 1},
            tags=['BIRD', 'question-only', 'no-sql-pair', 'nl2sql-api'],
        )
        expected_suite_items = [{
            'data': {'question': record['question']},
            'description': f"BIRD question {record['question_id']} | {record['case_id']}",
            'assertions': [policy['gold_sql_assertion_template'].format(gold_sql=record['gold_sql'])],
        } for record in records]
        suite_items = suite.get_items()
        if not suite_items:
            suite.add_items(expected_suite_items)
            suite_items = suite.get_items()
        if len(suite_items) != 30 or suite.get_assertions() != policy['assertions']:
            raise RuntimeError('Opik suite did not persist the expected global assertions and 30 records')
        write(args.output_dir / 'suite-created.json', {
            'id': client.get_dataset(suite_name, project_name=lock['project_name']).id,
            'name': suite_name, 'description': suite.description,
            'global_assertions': suite.get_assertions(), 'items': suite_items,
            'input_protocol': 'question_only', 'gold_sql_location': 'item_assertion',
        })
        expected_items = {f"BIRD question {record['question_id']} | {record['case_id']}": record
                          for record in records}
        items_by_description = {item['description']: item for item in suite_items}
        if set(items_by_description) != set(expected_items):
            raise RuntimeError('Opik suite item descriptions differ from the frozen cohort')
        for description, record in expected_items.items():
            item = items_by_description[description]
            expected_assertion = policy['gold_sql_assertion_template'].format(gold_sql=record['gold_sql'])
            if item['data'] != {'question': record['question']} or item['assertions'] != [expected_assertion]:
                raise RuntimeError('Opik Test Data or per-question Gold SQL assertion differs')

        suite_import = args.output_dir / 'test-suite-items.jsonl'
        suite_import.write_text(''.join(json.dumps({
            'data': item['data'], 'description': item['description'], 'assertions': item['assertions']
        }, ensure_ascii=False) + '\n' for item in suite_items))
        (args.output_dir / 'runner-source.py').write_bytes(Path(__file__).read_bytes())
        write(args.output_dir / 'manifest.json', {
            'protocol': 'question_only', 'evidence_sent_to_nl2sql': False,
            'sql_pair_knowledge_used': False, 'source_experiment': bundle['experiment'],
            'records_sha256': sha256(args.records), 'policy_sha256': sha256(args.policy),
            'runner_sha256': sha256(__file__), 'official_evaluator': policy['evaluator_url'],
            'official_evaluator_sha256': policy['evaluator_sha256'],
                'opik_sdk_version': importlib.metadata.version('opik'), 'judge_model': judge_model,
                'api_url': args.api_url, 'project': args.project, 'runtime': frozen_runtime,
                'planned_api_calls': 30, 'worker_threads': args.worker_threads,
            'cohort_question_ids': [record['question_id'] for record in records],
            'source_evidence_retained_for_human_review_only': True,
        })
        outcomes = {}
        outcomes_lock = Lock()
        task_local = local()
        task_resources = []
        task_resources_lock = Lock()

        def task(item):
            if not hasattr(task_local, 'api'):
                task_local.api = httpx.Client(
                    base_url=args.api_url, trust_env=False, timeout=args.api_timeout_seconds)
                task_local.scorer = psycopg.connect(dsn, autocommit=True)
                with task_resources_lock:
                    task_resources.append((task_local.api, task_local.scorer))
            task_api, task_conn = task_local.api, task_local.scorer
            question = item['question']
            record = by_question[question]
            request_body = question_only_request(item)
            if set(request_body) != {'query'} or request_body['query'] != question:
                raise RuntimeError('NL2SQL API request is not question-only')
            request_path = args.output_dir / record['question_id']
            request_path.mkdir()
            write(request_path / 'api-request.json', {
                'method': 'POST', 'path': '/api/nl2sql',
                'params': {'projectId': args.project}, 'body': request_body,
            })
            before = read_json_api(task_api, '/api/config/active', args.project)
            if {key: before.get(key) for key in frozen_runtime} != frozen_runtime:
                raise RuntimeError('Active NL2SQL runtime changed during the Opik suite run')
            started = time.perf_counter()
            try:
                response = task_api.post('/api/nl2sql', params={'projectId': args.project}, json=request_body)
                elapsed_ms = (time.perf_counter() - started) * 1000
                api_payload = response.json()
            except (httpx.TimeoutException, httpx.RequestError, json.JSONDecodeError) as exc:
                elapsed_ms = (time.perf_counter() - started) * 1000
                response = None
                api_payload = {'status': 'error', 'error': {'type': type(exc).__name__, 'message': str(exc)}}
            write(request_path / 'api-response.json', {
                'http_status': response.status_code if response is not None else None,
                'body': api_payload,
            })
            api_error = None
            if response is None:
                api_error = 'nl2sql_api_timeout' if 'Timeout' in api_payload['error']['type'] else 'nl2sql_api_error'
            elif response.status_code != 200:
                api_error = 'nl2sql_api_http_error'
            elif api_payload.get('status') != 'success':
                api_error = 'nl2sql_error'
            if response is not None and response.status_code == 200:
                if api_payload.get('query') != question:
                    raise RuntimeError('NL2SQL API response query differs from the question-only request')
                query_id, thread_id, trace_id = (api_payload.get('queryId'), api_payload.get('threadId'),
                                                 api_payload.get('traceId'))
            else:
                query_id = thread_id = trace_id = None
            audits, knowledge_proof, trace_status = [], {'status': 'not_available'}, None
            if query_id:
                audits = collect_knowledge_audit(task_api, args.project, query_id)
                knowledge_proof = validate_empty_knowledge(audits, query_id, thread_id, trace_id)
                trace_response = task_api.get(
                    f'/api/langfuse/workflow-trace/by-query-id/{query_id}',
                    params={'projectId': args.project, 'exposeSql': 'true'},
                )
                trace_status = trace_response.status_code
                if trace_response.is_success:
                    trace_data = trace_response.json()
                    if trace_data.get('traceId') != trace_id:
                        raise RuntimeError('NL2SQL API trace readback identity differs')
                    write(request_path / 'api-trace.json', trace_data)
                else:
                    write(request_path / 'api-trace-error.json', {'status': trace_response.status_code,
                                                                  'body': trace_response.text[:2000]})
            prediction = api_payload.get('sql') if not api_error else None
            score = score_case(task_conn, prediction, record['gold_sql'], args.sql_timeout_ms)
            ex = 0 if api_error else score['ex']
            error = api_error or score['error']
            f1 = 0.0 if score['predicted_rows'] is None else calculate_f1(
                score['predicted_rows'], score['gold_rows'])
            outcome = {
                'case_id': record['case_id'], 'question_id': record['question_id'],
                'question': question, 'protocol': 'question_only', 'evidence_sent': False,
                'api_status': api_payload.get('status'), 'api_http_status': response.status_code if response else None,
                'api_error': api_error, 'sql': prediction, 'EX': ex, 'BIRD_SoftF1': f1,
                'error': error, 'timeout': 'timeout' in str(error), 'ask_ms': elapsed_ms,
                'scorer_ms': score['scorer_ms'], 'gold_rows': score['gold_rows'],
                'actual_rows': score['predicted_rows'], 'official_result': api_payload.get('results', []),
                'queryId': query_id, 'threadId': thread_id, 'traceId': trace_id,
                'sql_pair_proof': knowledge_proof, 'trace_http_status': trace_status,
            }
            with outcomes_lock:
                outcomes[record['question_id']] = outcome
            write_encoded(request_path / 'score.json', outcome)
            judge_output = {
                'case_id': record['case_id'], 'question_id': record['question_id'],
                'status': api_payload.get('status'), 'sql': api_payload.get('sql', ''),
                'results': api_payload.get('results', []), 'error': api_error,
                'queryId': query_id, 'traceId': trace_id,
            }
            return {'input': {'question': question}, 'output': judge_output}

        try:
            suite_result = suite.run(
                task=task, model=judge_model, project_name=lock['project_name'],
                experiment_name=suite_name + '-run',
                experiment_config={'protocol': 'question_only', 'evidence_sent_to_nl2sql': False,
                                   'sql_pair_knowledge_used': False, 'runtime': frozen_runtime,
                                   'api_endpoint': '/api/nl2sql', 'new_nl2sql_calls': 30,
                                   'worker_threads': args.worker_threads, 'source_experiment': bundle['experiment']},
                worker_threads=args.worker_threads, verbose=1,
                report_output_path=str(args.output_dir / 'suite-report.json'),
            )
        finally:
            for task_api, task_conn in task_resources:
                task_api.close()
                task_conn.close()
        report = suite_result.to_report_dict()
        write(args.output_dir / 'suite-report.json', report)
        if suite_result.items_total != 30 or set(outcomes) != {r['question_id'] for r in records}:
            raise RuntimeError('Opik suite did not call the NL2SQL API once for all 30 questions')
        active_after = read_json_api(api, '/api/config/active', args.project)
        if {key: active_after.get(key) for key in frozen_runtime} != frozen_runtime:
            raise RuntimeError('Active NL2SQL runtime changed during the Opik suite run')

        suite_dataset = client.get_dataset(suite_name, project_name=lock['project_name'])
        suite_version = suite_dataset.get_version_view(suite.get_current_version_name())

        class OfficialMetrics(BaseMetric):
            def score(self, EX, BIRD_SoftF1, error, timeout, ask_ms, scorer_ms, **ignored):
                return [ScoreResult(name='EX', value=EX, reason=error or 'Complete read-only BIRD result comparison'),
                        ScoreResult(name='BIRD_SoftF1', value=round(BIRD_SoftF1, 6),
                                    reason='Unmodified official BIRD beta metric on complete independent result rows'),
                        ScoreResult(name='error', value=int(bool(error)), reason=str(error or 'none')),
                        ScoreResult(name='timeout', value=int(timeout)),
                        ScoreResult(name='ask_ms', value=round(ask_ms, 6)),
                        ScoreResult(name='scorer_ms', value=round(scorer_ms, 6))]

        metric_outputs = {outcome['question']: json.loads(json.dumps(outcome, default=encode))
                          for outcome in outcomes.values()}
        metric_name = suite_name + '-official-metrics'
        metric_result = evaluate(
            dataset=suite_version,
            task=lambda item: metric_outputs[item['question']],
            scoring_metrics=[OfficialMetrics(track=False)], project_name=lock['project_name'],
            experiment_name=metric_name,
            experiment_config={'metric_mode': 'saved_api_output_replay', 'api_calls': 30,
                               'protocol': 'question_only', 'evidence_sent_to_nl2sql': False,
                               'runtime': frozen_runtime},
            task_threads=1, trial_count=1, verbose=0,
        )
        if len(metric_result.test_results) != 30 or any(
                score.scoring_failed for test in metric_result.test_results for score in test.score_results):
            raise RuntimeError('Official metrics could not be published for all API outputs')
        opik.flush_tracker(); client.flush()
        suite_readback = readback(client, suite_result.experiment_id, suite_name + '-run',
                                  lock['project_name'], 30)
        metrics_readback = readback(client, metric_result.experiment_id, metric_name,
                                    lock['project_name'], 30)
        if suite_readback['experiment']['dataset_version_id'] != suite.get_version_info().id:
            raise RuntimeError('Persisted Opik suite run uses a different suite version')
        outcomes_by_qid = {outcome['question_id']: outcome for outcome in outcomes.values()}
        for item in suite_readback['items']:
            output = item['output']
            expected = outcomes_by_qid[output['question_id']]
            if (item['input'] != {'question': expected['question']} or
                    output.get('queryId') != expected['queryId'] or
                    'evidence' in item['input'] or 'gold_sql' in item['input'] or
                    'gold_sql' in output):
                raise RuntimeError('Persisted Opik suite trace differs from its question-only API result')
        if metrics_readback['experiment']['dataset_version_id'] != suite.get_version_info().id:
            raise RuntimeError('Persisted official metrics use a different suite version')
        for item in metrics_readback['items']:
            expected = metric_outputs[item['input']['question']]
            if item['output'] != expected:
                raise RuntimeError('Persisted Opik metric output differs from the API result')
            scores = {score['name']: score['value'] for score in item['feedback_scores']}
            if (scores.get('EX') != expected['EX'] or
                    round(scores.get('BIRD_SoftF1', -1), 6) != round(expected['BIRD_SoftF1'], 6)):
                raise RuntimeError('Persisted Opik official scores differ from the independent scorer')
        write(args.output_dir / 'suite-readback.json', suite_readback)
        write(args.output_dir / 'metrics-readback.json', metrics_readback)
        gold_validation = compare_gold_assertions(report, suite_items, outcomes)
        write(args.output_dir / 'gold-sql-assertion-validation.json', gold_validation)

    ex_count = sum(outcome['EX'] for outcome in outcomes.values())
    summary = {
        'protocol': 'question_only', 'records': len(records), 'nl2sql_api_calls': len(outcomes),
        'new_nl2sql_calls': len(outcomes), 'worker_threads': args.worker_threads,
        'evidence_sent_to_nl2sql': False,
        'sql_pair_knowledge_used': False, 'EX': ex_count, 'accuracy': ex_count / len(records),
        'average_BIRD_SoftF1': sum(o['BIRD_SoftF1'] for o in outcomes.values()) / len(outcomes),
        'suite_id': suite.id, 'suite_experiment_id': suite_result.experiment_id,
        'suite_passed': suite_result.items_passed, 'suite_total': suite_result.items_total,
        'gold_sql_assertion_passed': gold_validation['judge_passed'],
        'gold_sql_assertion_agreement_with_official_EX': gold_validation['agreement_rate'],
        'official_metrics_experiment_id': metric_result.experiment_id,
        'human_review_submitted': 0,
    }
    write(args.output_dir / 'summary.json', summary)
    write_encoded(args.output_dir / 'outcomes.json', list(outcomes.values()))
    write(args.output_dir / 'verification.json', {
        'all_30_questions_called_once': len(outcomes) == 30,
        'test_data_contains_question_only': all(item['data'].keys() == {'question'} for item in suite_items),
        'per_question_gold_sql_assertions': all(len(item['assertions']) == 1 for item in suite_items),
        'evidence_sent_to_nl2sql': False,
        'sql_pair_knowledge_used': False,
        'all_assertion_results_scored': len(gold_validation['cases']) == 30,
        'official_score_from_independent_read_only_execution': True,
    })
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
