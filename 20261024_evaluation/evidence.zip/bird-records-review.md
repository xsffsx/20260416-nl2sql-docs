# BIRD 30 条逐题分析页自审

完成时间：2026-10-24T17:05:35+08:00

页面：http://127.0.0.1:3001/20260416-nl2sql-docs/docs/examples/bird-baseline-30-records-analyst/

## 范围与交付

- 原实验 `bird-debit-baseline-full-20261024-0800` 的30题逐一分析；不重跑模型，不调整 Gold、EX 或 Snapshot。
- 每题有中文题意、原EX与Ask、Gold/实际结果、差异分析与解释；折叠保存英文原题、官方evidence及两份完整SQL。
- 30条索引可跳转；完整结果附件保留所有行及score原文件SHA-256。1500正文节选，附件保留976行、27种去重描述。
- 导航为“BIRD 无 SQL Pair 基线”父级及“BIRD 无 SQL Pair 30 records analyst”子级；父页新增正文入口，原URL保持可用。

## 结果复核

| 检查 | 证据与结果 |
| --- | --- |
| 题目覆盖 | 30个题号及顺序与run-manifest完全一致；EX相加9 |
| 未通过的互斥结果分类 | 15条非空但列数不同；5条同列数值不同；1条空集，共21条；不当作互斥原因分类 |
| 页面SQL | 30个折叠区逐一正常展开/收起；浏览器按代码行读取60段SQL，逐一与冻结数据精确核对 |
| 原题与追查 | 同一浏览器循环逐一核对英文Question与queryId；全部30条通过 |
| 来源保护 | 259个原始证据、14个既有公开文件、35张既有图片的SHA-256未变 |
| 新附件 | records.json与checksums.json均HTTP200，字节与本地公开文件相同；30份score内容及hash匹配原文件 |
| 公开内容 | 无机器绝对路径、认证头或密钥字段；附件保留query/thread/trace与Snapshot身份用于追查 |
| 构建 | 最终pnpm --dir docs-site build通过；日志/tmp/bird-guide-20261024/build-records-final.log |
| 浏览器 | 隔离AI Chrome、CDP9223、Playwright MCP8931；1366×900，30题标题、30个折叠区，页面无整体横向溢出 |
| 链接 | 父页正文到子页、侧栏子页、题号锚点、外部比较回链实际点击；外部比较目标标题存在；最终子页刷新成功 |

## 老板视角自审

- 首屏给出9/30（30%）、研究范围与来源；不用展开SQL就能读懂每题为何通过或不匹配。
- 1472、1484、1486明确目标值正确但多返回列；1498说明月度聚合与单条记录最大值差异；1493解释舍入。
- 1514说明重复行为何仍通过；1509说明本次结果一致不能证明SQL在所有数据上等价。
- 1482、1526、1531明确题意/evidence与Gold差异；其他粒度及关联疑点分别列出。原始EX不改，也不擅自给生成SQL判语义正确。
- 总结分开说明输出契约、计算口径与参考集质量；没有“删列即可额外通过15题”或从无SQL Pair推断因果。
- 没有外部系统在同一30题上的逐题结果，因此保留条件对齐要求与原Guide的外部参考，不制造对手分数或排名。
- 实际发现并修正MDX比较运算符转义、中文加粗标签及外部比较锚点；最终构建与浏览器核对通过。

## 检查边界

本轮仅新增静态文档与原始结果副本、调整导航及父页入口；未调用模型、改动产品逻辑、重跑数据库评估或运行后端测试。SQL长行沿用站点代码块横向滚动，中文分析位于正文。自审由代理本人完成，不声称第三方独立评审。没有提交或更改Git index。

## 本地审阅截图

- [records-1472.png](bird-records-review-images/records-1472.png) · SHA-256 `e62c46c7c4281b29467ec772370f8d482915aaa9602594f24e31bd3c3b9934c3`
- [records-1526-sql.png](bird-records-review-images/records-1526-sql.png) · SHA-256 `4f8d367a79baa24e761c428ce28a04ee9e6c28018d928b3b246b94cb2aba7460`
- [records-bottom.png](bird-records-review-images/records-bottom.png) · SHA-256 `87661fa216248b2448a397c315c6d2af3ebd44387d8a882fe59669377dd20c49`
- [records-sidebar.png](bird-records-review-images/records-sidebar.png) · SHA-256 `36bd0960efd2fb61e9c21c4871b0a2b317d8f844b2aa02227cddc08fc6663d72`
- [records-summary.png](bird-records-review-images/records-summary.png) · SHA-256 `5c8b5a7a27bb2d6c8dc87178371d25a47ad22b44f7dfa0e47294ca859fa58081`
- [records-top.png](bird-records-review-images/records-top.png) · SHA-256 `f7c3a03d3f959204cc3cdfe52dc131537fdd535ac57fc880f99950b5c8c5ea46`
