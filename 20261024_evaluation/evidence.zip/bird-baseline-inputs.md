# BIRD 借记卡域固定输入

目标项目：`bird_baseline_20261024`。用户于 2026-10-24 确认使用新空 POC 项目，原 `debit_card_specializing` 项目及其未关联表保留。新 Query DB/schema/上传角色彼此隔离；独立只读角色只获新 schema 的 SELECT。凭证仅在忽略的本地 env 中。

固定契约见 [source lock](../../script/evaluation/bird-debit-source-lock.json)。QA 来自 BIRD 官方 Hugging Face 不可变修订；数据库来自官方完整包，以归档和 SQLite 成员双重 SHA-256 固定。许可 CC-BY-SA-4.0，归属 BIRD Team / BIRD-SQL。30 题全部使用官方 evidence。

| CSV | 完整行数 | 列数 |
| --- | ---: | ---: |
| `tables/customers.csv` | 32,461 | 3 |
| `tables/gasstations.csv` | 5,716 | 4 |
| `tables/products.csv` | 591 | 2 |
| `tables/transactions_1k.csv` | 1,000 | 9 |
| `tables/yearmonth.csv` | 383,282 | 3 |

共 423,050 行、21 列。题号顺序：

1471, 1472, 1473, 1476, 1479, 1480, 1481, 1482, 1483, 1484, 1486, 1490, 1493, 1498, 1500, 1501, 1505, 1506, 1507, 1509, 1514, 1515, 1521, 1524, 1525, 1526, 1528, 1529, 1531, 1533。

`yearmonth.date` 源类型 TEXT，通过正常 Review 覆盖 CSV 的 BIGINT 推断。其余确认类型、所有源名/目标名和每个 CSV 哈希均在 source lock 中。源 REAL 的文本表示导入 NUMERIC；DATE/TIME 经原 CSV uploader 转换。本域不存在 NULL 或空字符串；重建发现该契约变化即失败，不混淆两者。

## 从干净目录重建

安装独立依赖：

```bash
uv venv --python src/backend_py/.venv/bin/python script/evaluation/.venv
uv pip install --python script/evaluation/.venv/bin/python -r script/evaluation/requirements.txt
```

独立下载两个官方输入：

```bash
mkdir -p /tmp/bird-inputs
curl --fail --location 'https://huggingface.co/datasets/birdsql/bird_mini_dev/resolve/f65faf4ae3b638c1fa6df1d3370c8d92c8366301/data/mini_dev_pg-00000-of-00001.json' -o /tmp/bird-inputs/official-pg.json
curl --fail --location 'https://drive.usercontent.google.com/download?id=13VLWIwpw5E3d5DUkMvzw7hvHE67a4XkG&export=download&confirm=t' -o /tmp/bird-inputs/minidev_0703.zip
script/evaluation/.venv/bin/python script/evaluation/run_bird_baseline.py prepare \
  --source-lock script/evaluation/bird-debit-source-lock.json \
  --source-archive /tmp/bird-inputs/minidev_0703.zip \
  --official-qa /tmp/bird-inputs/official-pg.json \
  --output-dir /tmp/bird-inputs/new-pack
```

输出目录必须不存在。入口先验证原始输入 SHA-256，再只读打开 SQLite、重建 5 个完整 CSV、逐文件比对固定哈希、核对 30 题官方 QA，最后审计 Gold 语法树。原始 PostgreSQL Gold 保留；只允许审阅后的列名映射，不允许表达式变化。`input-manifest.json` 的状态明确保留目标执行待验证，不把文件准备等同于运行就绪。

实际在两个独立空目录 `rebuilt-1`、`rebuilt-2` 重建成功，5 个 CSV 哈希均与原包相同。无需被忽略的旧 CSV 包即可重建。文件缺失、哈希错误、可变修订、重复题号、源 Gold 差异或未批准表达式改写的测试均通过。

## 实际上传与 Gold 验证

已通过 UI 上传全部 CSV、逐表 Review、Create schema，独立只读核对目标全部行的类型和值后正常 Publish。没有手工创建业务表。

- [上传后 Draft](bird-upload-draft.json)：5 表均 Pending Publish，Active 为空。
- [全部数据核对](bird-upload-content.json)：423,050 行逐值比较通过，保留重复行计数及类型。
- [发布与 readiness](bird-published-readiness.json)：空 SQL Pair、完整 runtime binding、Schema RAG consistent、QA ready。
- [30 条 Gold 目标执行](bird-gold-target-validation.json)：每题独立执行成功，保留完整结果；不含模型预测。

这些是准备证据，不能当作模型 EX。原 HTML、draw.io、全局忽略规则和 Git index 未修改。
